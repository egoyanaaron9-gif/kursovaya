"""HTTP-сервер на стандартной библиотеке Python.

Запуск:  python server.py
Адрес:   http://127.0.0.1:8000/api/v1
"""
import json
import os
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qsl, urlparse

import api
import services
from services import ApiError

API_PREFIX = "/api/v1"
ALLOWED_ORIGINS = {o.strip() for o in os.environ.get(
    "ALLOWED_ORIGINS", "http://127.0.0.1:5500,http://localhost:5500").split(",") if o.strip()}


class Handler(BaseHTTPRequestHandler):
    server_version = "CollegeAPI/1.0"

    def log_message(self, format, *args):
        pass  # журнал действий ведётся в базе (audit_log), консоль не засоряем

    def _cors(self):
        origin = self.headers.get("Origin", "")
        if origin in ALLOWED_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Webhook-Secret")

    def _reply(self, status, payload, ctype="application/json; charset=utf-8"):
        if isinstance(payload, str):
            data = payload.encode("utf-8")
        else:
            data = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _error(self, status, code, message, fields=None):
        self._reply(status, {"error": {"code": code, "message": message, "fields": fields or {}}})

    def _handle(self, method):
        parsed = urlparse(self.path)
        if not parsed.path.startswith(API_PREFIX):
            return self._error(404, "NOT_FOUND", "Адрес должен начинаться с /api/v1")
        path = parsed.path[len(API_PREFIX):]

        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b""
        body = None
        if raw:
            try:
                body = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                return self._error(400, "INVALID_JSON", "Тело запроса не является корректным JSON")

        auth = self.headers.get("Authorization", "") or ""
        token = auth[7:].strip() if auth.startswith("Bearer ") else None
        query = dict(parse_qsl(parsed.query))

        try:
            result = api.dispatch(method, path, query, body, token, self.headers)
        except ApiError as e:
            return self._error(e.status, e.code, e.message, e.fields)
        except Exception:
            traceback.print_exc()
            return self._error(500, "INTERNAL_ERROR", "Внутренняя ошибка сервера")

        if len(result) == 3:
            self._reply(result[0], result[1], result[2])
        else:
            self._reply(result[0], result[1])

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_PATCH(self):
        self._handle("PATCH")

    def do_DELETE(self):
        self._handle("DELETE")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()


def main():
    services.ensure_initial_data()
    if "WEBHOOK_SECRET" not in os.environ:
        print("[warn] WEBHOOK_SECRET не задан, используется учебное значение. Задайте его перед запуском.")
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    print(f"API запущен: http://{host}:{port}{API_PREFIX}  (остановка: Ctrl+C)")
    ThreadingHTTPServer((host, port), Handler).serve_forever()


if __name__ == "__main__":
    main()
