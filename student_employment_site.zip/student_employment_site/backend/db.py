"""Подключение к базе данных.

Используется SQLite из стандартной библиотеки Python: файл college.db создаётся сам,
ничего устанавливать не нужно. Для PostgreSQL см. README.md.
"""
import os
import sqlite3
import threading

DB_PATH = os.environ.get("DB_PATH", "college.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    last_login_at TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS graduates (
    id TEXT PRIMARY KEY,
    external_id TEXT UNIQUE,
    full_name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    group_name TEXT,
    specialty_code TEXT,
    specialty TEXT,
    graduation_year INTEGER,
    status TEXT NOT NULL DEFAULT 'student',
    city TEXT,
    region TEXT,
    consent_personal_data INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    deleted_at TEXT
);

CREATE TABLE IF NOT EXISTS employments (
    id TEXT PRIMARY KEY,
    graduate_id TEXT NOT NULL REFERENCES graduates(id),
    company_name TEXT,
    job_position TEXT,
    employment_type TEXT,
    is_by_specialty INTEGER,
    salary REAL,
    currency TEXT,
    salary_period TEXT,
    is_current INTEGER NOT NULL DEFAULT 1,
    source_response_id TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS surveys (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    provider TEXT NOT NULL DEFAULT 'internal',
    external_form_id TEXT,
    form_url TEXT,
    graduation_years TEXT NOT NULL DEFAULT '',
    audience TEXT,
    target_count INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'draft',
    start_date TEXT,
    end_date TEXT,
    questions_schema TEXT NOT NULL DEFAULT '[]',
    created_by TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS survey_responses (
    id TEXT PRIMARY KEY,
    survey_id TEXT REFERENCES surveys(id),
    graduate_id TEXT REFERENCES graduates(id),
    respondent_identifier TEXT,
    source TEXT NOT NULL,
    raw_payload TEXT NOT NULL,
    processed_payload TEXT,
    status TEXT NOT NULL DEFAULT 'received',
    error_message TEXT,
    received_at TEXT NOT NULL,
    applied_at TEXT
);

CREATE TABLE IF NOT EXISTS directories (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    value TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS integrations (
    provider TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    url TEXT,
    status TEXT NOT NULL DEFAULT 'Не подключено'
);

CREATE TABLE IF NOT EXISTS audit_log (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id TEXT,
    details TEXT,
    created_at TEXT NOT NULL
);
"""

_lock = threading.RLock()
_conn = None


def _connection():
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA foreign_keys = ON")
        _conn.executescript(SCHEMA)
        _conn.commit()
    return _conn


def fetch_all(sql, params=()):
    with _lock:
        rows = _connection().execute(sql, tuple(params)).fetchall()
    return [dict(row) for row in rows]


def fetch_one(sql, params=()):
    rows = fetch_all(sql, params)
    return rows[0] if rows else None


def run(sql, params=()):
    with _lock:
        conn = _connection()
        conn.execute(sql, tuple(params))
        conn.commit()
