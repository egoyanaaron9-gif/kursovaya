"""Таблица адресов API: метод, путь, функция и роли, которым разрешён доступ.

roles=None означает публичный адрес (вход не нужен).
"""
import hmac
import os
import re

import services as s
from services import ApiError

DEV_WEBHOOK_SECRET = "dev-secret-change-me"

WRITERS = ("admin", "curator")                    # заводят и меняют данные
READERS = ("admin", "curator", "analyst")         # видят персональные данные
ANY_STAFF = s.STAFF_ROLES                         # любой сотрудник (включая директора)
ADMIN_ONLY = ("admin",)


class Ctx:
    def __init__(self, params, query, body, user, token, headers):
        self.params = params
        self.query = query
        self.body = body
        self.user = user
        self.token = token
        self.headers = headers


def _body(ctx, required=()):
    if not isinstance(ctx.body, dict):
        raise ApiError(400, "VALIDATION_ERROR", "Ожидается JSON-объект в теле запроса")
    missing = {f: "required" for f in required if ctx.body.get(f) in (None, "")}
    if missing:
        raise ApiError(422, "VALIDATION_ERROR", "Не заполнены обязательные поля", missing)
    return ctx.body


# ---------------------------------------------------------------- вход и профиль

def login(ctx):
    b = _body(ctx, required=("email", "password"))
    return 200, s.login(b["email"], b["password"])


def logout(ctx):
    s.logout(ctx.token)
    return 200, {"ok": True}


def me(ctx):
    return 200, s.user_out(ctx.user)


def me_patch(ctx):
    return 200, s.update_profile(ctx.user, _body(ctx))


# ---------------------------------------------------------------- выпускники

def graduates_list(ctx):
    return 200, s.list_graduates(ctx.query)


def graduates_create(ctx):
    return 201, s.create_graduate(_body(ctx), ctx.user)


def graduates_get(ctx):
    return 200, s.get_graduate(ctx.params["id"])


def graduates_patch(ctx):
    return 200, s.update_graduate(ctx.params["id"], _body(ctx), ctx.user)


def graduates_delete(ctx):
    s.delete_graduate(ctx.params["id"], ctx.user)
    return 200, {"ok": True}


# ---------------------------------------------------------------- опросы и ответы

def surveys_list(ctx):
    return 200, s.list_surveys(ctx.query)


def surveys_create(ctx):
    return 201, s.create_survey(_body(ctx, required=("title",)), ctx.user)


def surveys_get(ctx):
    return 200, s.get_survey(ctx.params["id"])


def surveys_patch(ctx):
    return 200, s.update_survey(ctx.params["id"], _body(ctx), ctx.user)


def surveys_delete(ctx):
    s.delete_survey(ctx.params["id"], ctx.user)
    return 200, {"ok": True}


def responses_list(ctx):
    return 200, s.list_responses(ctx.query)


def responses_get(ctx):
    return 200, s.get_response(ctx.params["id"])


def responses_patch(ctx):
    return 200, s.update_response(ctx.params["id"], _body(ctx), ctx.user)


def responses_delete(ctx):
    s.delete_response(ctx.params["id"], ctx.user)
    return 200, {"ok": True}


def public_survey_get(ctx):
    return 200, s.public_survey(ctx.params["id"])


def public_submit(ctx):
    return 201, s.process_public_submission(ctx.params["id"], _body(ctx))


def webhook(provider):
    def handler(ctx):
        secret = os.environ.get("WEBHOOK_SECRET", DEV_WEBHOOK_SECRET)
        given = ctx.headers.get("X-Webhook-Secret", "") or ""
        if not hmac.compare_digest(given.encode("utf-8"), secret.encode("utf-8")):
            raise ApiError(401, "BAD_WEBHOOK_SECRET", "Неверный секрет webhook")
        return 201, s.process_form_webhook(ctx.params["id"], _body(ctx), provider)
    return handler


# ---------------------------------------------------------------- импорт, отчёты, журнал

def imports_graduates(ctx):
    return 201, s.import_graduates(_body(ctx), ctx.user)


def reports_employment(ctx):
    report = s.employment_report(ctx.query)
    if ctx.query.get("format") == "csv":
        return 200, s.employment_report_csv(report), "text/csv; charset=utf-8"
    return 200, report


def audit_list(ctx):
    return 200, s.list_audit(ctx.query)


# ---------------------------------------------------------------- пользователи

def users_list(ctx):
    items = s.list_users()
    return 200, {"items": items, "total": len(items), "page": 1, "pageSize": len(items)}


def users_create(ctx):
    return 201, s.create_user(_body(ctx), ctx.user)


def users_patch(ctx):
    return 200, s.update_user(ctx.params["id"], _body(ctx), ctx.user)


def users_delete(ctx):
    s.delete_user(ctx.params["id"], ctx.user)
    return 200, {"ok": True}


# ---------------------------------------------------------------- справочники и интеграции

def directories_list(ctx):
    return 200, s.list_directory(ctx.params["type"])


def directories_create(ctx):
    return 201, s.create_directory(ctx.params["type"], _body(ctx), ctx.user)


def directories_patch(ctx):
    return 200, s.update_directory(ctx.params["type"], ctx.params["id"], _body(ctx), ctx.user)


def directories_delete(ctx):
    s.delete_directory(ctx.params["type"], ctx.params["id"], ctx.user)
    return 200, {"ok": True}


def integrations_list(ctx):
    return 200, s.list_integrations()


def integrations_patch(ctx):
    return 200, s.update_integration(ctx.params["provider"], _body(ctx), ctx.user)


# ---------------------------------------------------------------- таблица маршрутов

ROUTES = [
    ("POST",   r"/auth/login",                          login,               None),
    ("POST",   r"/auth/logout",                         logout,              ANY_STAFF),
    ("GET",    r"/auth/me",                             me,                  ANY_STAFF),
    ("PATCH",  r"/auth/me",                             me_patch,            ANY_STAFF),

    ("GET",    r"/graduates",                           graduates_list,      READERS),
    ("POST",   r"/graduates",                           graduates_create,    WRITERS),
    ("GET",    r"/graduates/(?P<id>[^/]+)",             graduates_get,       READERS),
    ("PATCH",  r"/graduates/(?P<id>[^/]+)",             graduates_patch,     WRITERS),
    ("DELETE", r"/graduates/(?P<id>[^/]+)",             graduates_delete,    WRITERS),

    ("GET",    r"/surveys",                             surveys_list,        ANY_STAFF),
    ("POST",   r"/surveys",                             surveys_create,      WRITERS),
    ("GET",    r"/surveys/(?P<id>[^/]+)",               surveys_get,         ANY_STAFF),
    ("PATCH",  r"/surveys/(?P<id>[^/]+)",               surveys_patch,       WRITERS),
    ("DELETE", r"/surveys/(?P<id>[^/]+)",               surveys_delete,      WRITERS),

    ("GET",    r"/survey-responses",                    responses_list,      READERS),
    ("GET",    r"/survey-responses/(?P<id>[^/]+)",      responses_get,       READERS),
    ("PATCH",  r"/survey-responses/(?P<id>[^/]+)",      responses_patch,     WRITERS),
    ("DELETE", r"/survey-responses/(?P<id>[^/]+)",      responses_delete,    WRITERS),

    ("GET",    r"/public/surveys/(?P<id>[^/]+)",        public_survey_get,   None),
    ("POST",   r"/public/surveys/(?P<id>[^/]+)/responses", public_submit,    None),
    ("POST",   r"/webhooks/google-forms/(?P<id>[^/]+)", webhook("google_forms"), None),
    ("POST",   r"/webhooks/yandex-forms/(?P<id>[^/]+)", webhook("yandex_forms"), None),

    ("POST",   r"/imports/graduates",                   imports_graduates,   WRITERS),
    ("GET",    r"/reports/employment",                  reports_employment,  ANY_STAFF),
    ("GET",    r"/audit-log",                           audit_list,          ("admin", "curator")),

    ("GET",    r"/users",                               users_list,          ADMIN_ONLY),
    ("POST",   r"/users",                               users_create,        ADMIN_ONLY),
    ("PATCH",  r"/users/(?P<id>[^/]+)",                 users_patch,         ADMIN_ONLY),
    ("DELETE", r"/users/(?P<id>[^/]+)",                 users_delete,        ADMIN_ONLY),

    ("GET",    r"/directories/(?P<type>[^/]+)",         directories_list,    ANY_STAFF),
    ("POST",   r"/directories/(?P<type>[^/]+)",         directories_create,  WRITERS),
    ("PATCH",  r"/directories/(?P<type>[^/]+)/(?P<id>[^/]+)", directories_patch, WRITERS),
    ("DELETE", r"/directories/(?P<type>[^/]+)/(?P<id>[^/]+)", directories_delete, WRITERS),

    ("GET",    r"/integrations",                        integrations_list,   ANY_STAFF),
    ("PATCH",  r"/integrations/(?P<provider>[^/]+)",    integrations_patch,  ADMIN_ONLY),
]

COMPILED = [(m, re.compile("^" + p + "$"), h, r) for m, p, h, r in ROUTES]


def dispatch(method, path, query, body, token, headers):
    """Находит нужный адрес, проверяет вход и роль, вызывает обработчик."""
    path_found = False
    for route_method, pattern, handler, roles in COMPILED:
        match = pattern.match(path)
        if not match:
            continue
        path_found = True
        if route_method != method:
            continue
        user = None
        if roles is not None:
            if not token:
                raise ApiError(401, "UNAUTHORIZED", "Требуется вход в систему")
            user = s.user_by_token(token)
            if user is None:
                raise ApiError(401, "UNAUTHORIZED", "Сессия истекла, войдите снова")
            if user["role"] not in roles:
                raise ApiError(403, "FORBIDDEN", "Недостаточно прав для этого действия")
        return handler(Ctx(match.groupdict(), query, body, user, token, headers))
    if path_found:
        raise ApiError(405, "METHOD_NOT_ALLOWED", "Этот метод не поддерживается для данного адреса")
    raise ApiError(404, "NOT_FOUND", "Адрес не найден")
