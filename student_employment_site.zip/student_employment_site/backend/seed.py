"""Демо-данные для показа. Запуск: python seed.py

Скрипт ничего не дублирует: если выпускники уже есть, он выходит без изменений.
"""
import services
from db import fetch_one

DEMO_DIRECTORIES = {
    "specialties": ["Информационные системы", "Программирование",
                    "Экономика и бухгалтерский учёт", "Сетевое администрирование"],
    "employers": ["ООО «ТехСервис»", "ООО «Вектор»", "АО «Связь»", "ООО «Код»"],
    "skills": ["Python", "SQL", "JavaScript", "Работа с базами данных", "Командная работа"],
}

DEMO_GRADUATES = [
    dict(fullName="Иван Петров", email="i.petrov@example.ru", phone="+7 900 111-22-33", groupName="ИС-21",
         specialty="Информационные системы", graduationYear=2025, status="Трудоустроен",
         employment=dict(companyName="ООО «ТехСервис»", position="Системный аналитик",
                         employmentType="Полная", isBySpecialty=True, salary=72000)),
    dict(fullName="Мария Соколова", email="m.sokolova@example.ru", phone="+7 900 222-33-44", groupName="ЭК-22",
         specialty="Экономика и бухгалтерский учёт", graduationYear=2025, status="Трудоустроен",
         employment=dict(companyName="ООО «Вектор»", position="Бухгалтер",
                         employmentType="Полная", isBySpecialty=True, salary=58000)),
    dict(fullName="Артём Дмитриев", email="a.dmitriev@example.ru", phone="+7 900 333-44-55", groupName="ПР-21",
         specialty="Программирование", graduationYear=2025, status="Не трудоустроен"),
    dict(fullName="Екатерина Иванова", email="e.ivanova@example.ru", phone="+7 900 444-55-66", groupName="ИС-22",
         specialty="Информационные системы", graduationYear=2026, status="Студент выпускного курса"),
    dict(fullName="Дмитрий Козлов", email="d.kozlov@example.ru", phone="+7 900 555-66-77", groupName="СА-23",
         specialty="Сетевое администрирование", graduationYear=2024, status="Трудоустроен",
         employment=dict(companyName="АО «Связь»", position="Сетевой администратор",
                         employmentType="Полная", isBySpecialty=True, salary=65000)),
    dict(fullName="Анна Морозова", email="a.morozova@example.ru", phone="+7 900 666-77-88", groupName="ПР-22",
         specialty="Программирование", graduationYear=2025, status="Трудоустроен",
         employment=dict(companyName="ООО «Код»", position="Frontend-разработчик",
                         employmentType="Полная", isBySpecialty=False, salary=81000)),
    dict(fullName="Никита Волков", email="n.volkov@example.ru", phone="+7 900 777-88-99", groupName="ЭК-21",
         specialty="Экономика и бухгалтерский учёт", graduationYear=2024, status="Продолжает обучение"),
    dict(fullName="София Орлова", email="s.orlova@example.ru", phone="+7 900 888-99-00", groupName="ИС-23",
         specialty="Информационные системы", graduationYear=2026, status="Студент выпускного курса"),
]

DEMO_SURVEYS = [
    dict(title="Мониторинг трудоустройства 2025",
         description="Ежегодный сбор информации о текущем месте работы и профессиональной деятельности выпускников.",
         audience="Выпускники 2025 года", status="Активен", startDate="2026-10-01", endDate="2026-11-30",
         targetCount=40, questionsSchema=["Текущий статус занятости", "Название организации",
                                          "Работаете ли по специальности?"]),
    dict(title="Оценка профессиональных навыков",
         description="Опрос о навыках, которые выпускники применяют в своей профессиональной деятельности.",
         audience="Все выпускники", status="Активен", startDate="2026-09-15", endDate="2026-12-15",
         targetCount=60, questionsSchema=["Какие навыки используете в работе?", "Каких навыков не хватает?"]),
    dict(title="Трудоустройство выпускников 2024",
         description="Завершённый опрос для анализа карьерных траекторий выпускников 2024 года.",
         audience="Выпускники 2024 года", status="Завершён", startDate="2026-03-01", endDate="2026-04-30",
         targetCount=30, questionsSchema=["Текущий статус занятости", "Место работы"]),
]


def _response_body(graduate):
    employment = graduate.get("employment")
    status_label = graduate["status"]
    body = {
        "graduate": {"fullName": graduate["fullName"], "email": graduate["email"],
                     "groupName": graduate["groupName"], "specialty": graduate["specialty"],
                     "graduationYear": graduate["graduationYear"], "status": status_label},
        "consentPersonalData": True,
    }
    if employment:
        body["employment"] = dict(employment, status="employed", currency="RUB")
    return body


def main():
    services.ensure_initial_data()
    if fetch_one("SELECT id FROM graduates LIMIT 1"):
        print("Демо-данные уже есть, ничего не добавлено.")
        return
    admin = fetch_one("SELECT * FROM users WHERE role = 'admin' LIMIT 1")

    for dtype, values in DEMO_DIRECTORIES.items():
        for value in values:
            services.create_directory(dtype, {"value": value}, admin)

    for graduate in DEMO_GRADUATES:
        services.create_graduate(dict(graduate, consentPersonalData=True), admin)

    status_map = {"Черновик": "draft", "Активен": "active", "Завершён": "closed"}
    surveys = [services.create_survey(dict(s, status=status_map[s["status"]]), admin) for s in DEMO_SURVEYS]

    # несколько ответов для первого (активного) опроса
    for graduate in DEMO_GRADUATES[:3]:
        services.process_public_submission(surveys[0]["id"], _response_body(graduate))

    print(f"Демо-данные созданы: выпускников {len(DEMO_GRADUATES)}, опросов {len(surveys)}.")


if __name__ == "__main__":
    main()
