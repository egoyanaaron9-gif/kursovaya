"""Бизнес-логика: пользователи, выпускники, опросы, ответы, импорт, отчёты.

Функции api.py только принимают запрос и вызывают отсюда нужное действие.
"""
import csv
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import uuid
from datetime import datetime, timezone

from db import fetch_all, fetch_one, run

PASSWORD_ITERATIONS = 200_000

STAFF_ROLES = ("admin", "curator", "analyst", "director")
GRADUATE_STATUSES = ("student", "employed", "unemployed", "continuing_education", "other")
SURVEY_STATUSES = ("draft", "active", "closed")
PROVIDERS = ("internal", "google_forms", "yandex_forms")
RESPONSE_STATUSES = ("received", "parsed", "applied", "error")
IMPORT_SOURCES = ("college", "yandex_forms", "google_forms")

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class ApiError(Exception):
    """Ошибка для ответа клиенту: HTTP-код, машинный код, сообщение и поля."""

    def __init__(self, status, code, message, fields=None):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.fields = fields or {}


# ---------------------------------------------------------------- служебные функции

def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_id():
    return str(uuid.uuid4())


def insert_row(table, values):
    keys = list(values)
    sql = f"INSERT INTO {table} ({', '.join(keys)}) VALUES ({', '.join('?' * len(keys))})"
    run(sql, [values[k] for k in keys])


def update_row(table, row_id, values):
    if not values:
        return
    keys = list(values)
    sql = f"UPDATE {table} SET {', '.join(k + ' = ?' for k in keys)} WHERE id = ?"
    run(sql, [values[k] for k in keys] + [row_id])


def to_int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def to_number(value):
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(" ", "").replace(",", "."))
    except ValueError:
        return None


def to_bool(value):
    if isinstance(value, bool):
        return value
    text = str(value or "").strip().lower()
    return text.startswith(("да", "yes", "true", "1", "+", "я согласен", "я согласна", "согласен", "согласна"))


def paging(query):
    page = max(1, to_int(query.get("page")) or 1)
    size = min(100, max(1, to_int(query.get("pageSize")) or 20))
    return page, size


def paged(items, total, page, size):
    return {"items": items, "total": total, "page": page, "pageSize": size}


def audit(user, action, entity_type, entity_id, details=None):
    insert_row("audit_log", {
        "id": new_id(),
        "user_id": user["id"] if user else None,
        "action": action,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "details": json.dumps(details or {}, ensure_ascii=False),
        "created_at": now_iso(),
    })


def pct(part, whole):
    return round(part * 100 / whole, 1) if whole else 0


# ---------------------------------------------------------------- статусы

STATUS_ALIASES = [
    ("не трудоустро", "unemployed"), ("безработ", "unemployed"), ("не работ", "unemployed"), ("ищу", "unemployed"),
    ("продолж", "continuing_education"), ("учусь", "continuing_education"), ("поступил", "continuing_education"),
    ("трудоустро", "employed"), ("работа", "employed"),
    ("студент", "student"),
]


def normalize_status(value):
    """Переводит статус из анкеты («Работаю», «Учусь») в машинное значение."""
    text = str(value or "").strip().lower()
    if text in GRADUATE_STATUSES:
        return text
    for needle, code in STATUS_ALIASES:
        if needle in text:
            return code
    return "other"


def status_or_none(value):
    return normalize_status(value) if str(value or "").strip() else None


# ---------------------------------------------------------------- пользователи и вход

def hash_password(password):
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), PASSWORD_ITERATIONS).hex()
    return f"{salt}${digest}"


def check_password(password, stored):
    try:
        salt, digest = stored.split("$", 1)
    except ValueError:
        return False
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), PASSWORD_ITERATIONS).hex()
    return hmac.compare_digest(candidate, digest)


def ensure_admin():
    """При первом запуске создаёт администратора из переменных окружения."""
    if fetch_one("SELECT id FROM users LIMIT 1"):
        return
    email = os.environ.get("ADMIN_EMAIL", "admin@college.ru").strip().lower()
    password = os.environ.get("ADMIN_PASSWORD", "admin12345")
    insert_row("users", {
        "id": new_id(), "full_name": "Администратор", "email": email,
        "password_hash": hash_password(password), "role": "admin",
        "is_active": 1, "created_at": now_iso(),
    })
    print(f"[init] Создан администратор: {email}. Смените пароль через ADMIN_PASSWORD до запуска в работу.")


def user_out(user):
    return {"id": user["id"], "fullName": user["full_name"], "email": user["email"],
            "role": user["role"], "isActive": bool(user["is_active"])}


def login(email, password):
    user = fetch_one("SELECT * FROM users WHERE email = ?", (str(email).strip().lower(),))
    if not user or not user["is_active"] or not check_password(password, user["password_hash"]):
        raise ApiError(401, "INVALID_CREDENTIALS", "Неверный email или пароль")
    token = secrets.token_urlsafe(32)
    insert_row("sessions", {"token": token, "user_id": user["id"], "created_at": now_iso()})
    run("UPDATE users SET last_login_at = ? WHERE id = ?", (now_iso(), user["id"]))
    return {"accessToken": token, "tokenType": "Bearer", "user": user_out(user)}


def logout(token):
    run("DELETE FROM sessions WHERE token = ?", (token,))


def user_by_token(token):
    return fetch_one(
        "SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id "
        "WHERE s.token = ? AND u.is_active = 1", (token,))


def list_users():
    return [user_out(u) for u in fetch_all("SELECT * FROM users ORDER BY full_name")]


def create_user(data, actor):
    errors = {}
    email = str(data.get("email") or "").strip().lower()
    if not EMAIL_RE.match(email):
        errors["email"] = "invalid"
    if not str(data.get("fullName") or "").strip():
        errors["fullName"] = "required"
    role = data.get("role") or "curator"
    if role not in STAFF_ROLES:
        errors["role"] = "invalid"
    password = str(data.get("password") or "")
    if len(password) < 8:
        errors["password"] = "min_8_chars"
    if errors:
        raise ApiError(422, "VALIDATION_ERROR", "Проверьте заполненные поля", errors)
    if fetch_one("SELECT id FROM users WHERE email = ?", (email,)):
        raise ApiError(409, "DUPLICATE", "Пользователь с таким email уже есть")
    uid = new_id()
    insert_row("users", {
        "id": uid, "full_name": str(data["fullName"]).strip(), "email": email,
        "password_hash": hash_password(password), "role": role, "is_active": 1, "created_at": now_iso(),
    })
    audit(actor, "create", "user", uid, {"email": email, "role": role})
    return user_out(fetch_one("SELECT * FROM users WHERE id = ?", (uid,)))


def update_user(uid, data, actor):
    user = fetch_one("SELECT * FROM users WHERE id = ?", (uid,))
    if not user:
        raise ApiError(404, "NOT_FOUND", "Пользователь не найден")
    changes = {}
    if "fullName" in data:
        changes["full_name"] = str(data["fullName"]).strip()
    if "email" in data:
        email = str(data["email"] or "").strip().lower()
        if not EMAIL_RE.match(email):
            raise ApiError(422, "VALIDATION_ERROR", "Некорректный email", {"email": "invalid"})
        if fetch_one("SELECT id FROM users WHERE email = ? AND id != ?", (email, uid)):
            raise ApiError(409, "DUPLICATE", "Пользователь с таким email уже есть")
        changes["email"] = email
    if "role" in data:
        if data["role"] not in STAFF_ROLES:
            raise ApiError(422, "VALIDATION_ERROR", "Неизвестная роль", {"role": "invalid"})
        changes["role"] = data["role"]
    if "isActive" in data:
        changes["is_active"] = 1 if data["isActive"] else 0
    if data.get("password"):
        if len(str(data["password"])) < 8:
            raise ApiError(422, "VALIDATION_ERROR", "Пароль короче 8 символов", {"password": "min_8_chars"})
        changes["password_hash"] = hash_password(str(data["password"]))
    update_row("users", uid, changes)
    if changes.get("is_active") == 0:
        run("DELETE FROM sessions WHERE user_id = ?", (uid,))
    audit(actor, "update", "user", uid, {"fields": sorted(k for k in changes if k != "password_hash")})
    return user_out(fetch_one("SELECT * FROM users WHERE id = ?", (uid,)))


# ---------------------------------------------------------------- выпускники

GRADUATE_FIELDS = {
    "externalId": "external_id", "fullName": "full_name", "email": "email", "phone": "phone",
    "groupName": "group_name", "specialtyCode": "specialty_code", "specialty": "specialty",
    "graduationYear": "graduation_year", "status": "status", "city": "city", "region": "region",
}


def validate_graduate(data, partial=False):
    errors = {}
    clean = {}
    for api_key, column in GRADUATE_FIELDS.items():
        if api_key in data:
            value = data[api_key]
            clean[column] = None if value in (None, "") else str(value).strip()
    if "full_name" in clean and not clean["full_name"]:
        errors["fullName"] = "required"
    if not partial and not clean.get("full_name"):
        errors["fullName"] = "required"
    if clean.get("email"):
        clean["email"] = clean["email"].lower()
        if not EMAIL_RE.match(clean["email"]):
            errors["email"] = "invalid"
    if clean.get("graduation_year"):
        year = to_int(clean["graduation_year"])
        if year is None or not 2000 <= year <= 2100:
            errors["graduationYear"] = "invalid"
        else:
            clean["graduation_year"] = year
    if "status" in clean:
        clean["status"] = normalize_status(clean["status"])
    if "consentPersonalData" in data:
        clean["consent_personal_data"] = 1 if to_bool(data["consentPersonalData"]) else 0
    if errors:
        raise ApiError(422, "VALIDATION_ERROR", "Проверьте заполненные поля", errors)
    return clean


def employment_out(e):
    return {
        "id": e["id"], "companyName": e["company_name"], "position": e["job_position"],
        "employmentType": e["employment_type"],
        "isBySpecialty": None if e["is_by_specialty"] is None else bool(e["is_by_specialty"]),
        "salary": e["salary"], "currency": e["currency"], "salaryPeriod": e["salary_period"],
        "isCurrent": bool(e["is_current"]), "createdAt": e["created_at"],
    }


def graduate_out(row, full=True):
    out = {
        "id": row["id"], "externalId": row["external_id"], "fullName": row["full_name"],
        "email": row["email"], "phone": row["phone"], "groupName": row["group_name"],
        "specialtyCode": row["specialty_code"], "specialty": row["specialty"],
        "graduationYear": row["graduation_year"], "status": row["status"],
        "city": row["city"], "region": row["region"],
        "consentPersonalData": bool(row["consent_personal_data"]),
        "createdAt": row["created_at"], "updatedAt": row["updated_at"],
    }
    if full:
        employments = [employment_out(e) for e in fetch_all(
            "SELECT * FROM employments WHERE graduate_id = ? ORDER BY created_at DESC", (row["id"],))]
        out["employments"] = employments
        out["employment"] = next((e for e in employments if e["isCurrent"]), None)
    return out


def get_graduate_row(gid):
    row = fetch_one("SELECT * FROM graduates WHERE id = ? AND deleted_at IS NULL", (gid,))
    if not row:
        raise ApiError(404, "NOT_FOUND", "Выпускник не найден")
    return row


def get_graduate(gid):
    return graduate_out(get_graduate_row(gid))


def list_graduates(query):
    page, size = paging(query)
    where, params = ["deleted_at IS NULL"], []
    search = (query.get("search") or "").strip()
    if search:
        where.append("(full_name LIKE ? OR email LIKE ? OR group_name LIKE ?)")
        params += [f"%{search}%"] * 3
    year = to_int(query.get("graduationYear"))
    if year is not None:
        where.append("graduation_year = ?")
        params.append(year)
    status = query.get("status")
    if status in GRADUATE_STATUSES:
        where.append("status = ?")
        params.append(status)
    group = (query.get("groupName") or "").strip()
    if group:
        where.append("group_name = ?")
        params.append(group)
    where_sql = " AND ".join(where)
    total = fetch_one(f"SELECT COUNT(*) AS n FROM graduates WHERE {where_sql}", params)["n"]
    rows = fetch_all(
        f"SELECT * FROM graduates WHERE {where_sql} ORDER BY full_name LIMIT ? OFFSET ?",
        params + [size, (page - 1) * size])
    return paged([graduate_out(r) for r in rows], total, page, size)


def _employment_values(emp, source_response_id=None):
    return {
        "company_name": emp.get("companyName"), "job_position": emp.get("position"),
        "employment_type": emp.get("employmentType") or None,
        "is_by_specialty": None if emp.get("isBySpecialty") is None else (1 if emp["isBySpecialty"] else 0),
        "salary": emp.get("salary"), "currency": emp.get("currency") or "RUB",
        "salary_period": emp.get("salaryPeriod") or "month", "is_current": 1,
        "source_response_id": source_response_id,
    }


def set_current_employment(gid, emp, source_response_id=None):
    """Делает emp текущим местом работы. emp=None снимает текущую работу."""
    if emp is None:
        run("UPDATE employments SET is_current = 0 WHERE graduate_id = ?", (gid,))
        return
    values = _employment_values(emp, source_response_id)
    current = fetch_one(
        "SELECT id FROM employments WHERE graduate_id = ? AND is_current = 1 ORDER BY created_at DESC LIMIT 1", (gid,))
    if current:
        update_row("employments", current["id"], values)
    else:
        insert_row("employments", {"id": new_id(), "graduate_id": gid, "created_at": now_iso(), **values})


def employment_from(d, status):
    """Собирает место работы из входных данных. Возвращает None, если работы нет."""
    if not (d.get("companyName") or status == "employed"):
        return None
    by_spec = d.get("isBySpecialty")
    return {
        "companyName": d.get("companyName") or None,
        "position": d.get("position") or None,
        "employmentType": d.get("employmentType") or None,
        "isBySpecialty": None if by_spec in (None, "") else to_bool(by_spec),
        "salary": to_number(d.get("salary")),
        "currency": "RUB", "salaryPeriod": "month", "isCurrent": True,
    }


def create_graduate(data, actor):
    clean = validate_graduate(data)
    if not clean.get("consent_personal_data"):
        raise ApiError(422, "CONSENT_REQUIRED", "Нужно согласие на обработку персональных данных",
                       {"consentPersonalData": "required"})
    if clean.get("external_id") and fetch_one("SELECT id FROM graduates WHERE external_id = ?", (clean["external_id"],)):
        raise ApiError(409, "DUPLICATE", "Выпускник с таким внешним ID уже есть")
    if clean.get("email") and fetch_one(
            "SELECT id FROM graduates WHERE email = ? AND deleted_at IS NULL", (clean["email"],)):
        raise ApiError(409, "DUPLICATE", "Запись с таким email уже есть. Откройте её для редактирования.")
    gid, ts = new_id(), now_iso()
    clean.update({"id": gid, "created_at": ts, "updated_at": ts})
    insert_row("graduates", clean)
    if data.get("employment"):
        set_current_employment(gid, employment_from(data["employment"], "employed"))
    audit(actor, "create", "graduate", gid, {"fullName": clean["full_name"]})
    return get_graduate(gid)


def update_graduate(gid, data, actor):
    get_graduate_row(gid)
    clean = validate_graduate(data, partial=True)
    if clean.get("email") and fetch_one(
            "SELECT id FROM graduates WHERE email = ? AND id != ? AND deleted_at IS NULL", (clean["email"], gid)):
        raise ApiError(409, "DUPLICATE", "Запись с таким email уже есть.")
    if clean:
        clean["updated_at"] = now_iso()
        update_row("graduates", gid, clean)
    if "employment" in data:
        emp = data["employment"]
        set_current_employment(gid, employment_from(emp, "employed") if emp else None)
    audit(actor, "update", "graduate", gid, {"fields": sorted(clean)})
    return get_graduate(gid)


def delete_graduate(gid, actor):
    get_graduate_row(gid)
    update_row("graduates", gid, {"deleted_at": now_iso()})
    audit(actor, "delete", "graduate", gid)


# ---------------------------------------------------------------- опросы

SURVEY_TEXT_FIELDS = {
    "title": "title", "description": "description", "externalFormId": "external_form_id",
    "formUrl": "form_url", "startDate": "start_date", "endDate": "end_date", "audience": "audience",
}


def validate_survey(data, creating):
    errors = {}
    clean = {}
    for api_key, column in SURVEY_TEXT_FIELDS.items():
        if api_key in data:
            value = data[api_key]
            clean[column] = None if value in (None, "") else str(value).strip()
    if creating and not clean.get("title"):
        errors["title"] = "required"
    if "title" in clean and not clean["title"]:
        errors["title"] = "required"
    if "targetCount" in data:
        n = to_int(data["targetCount"])
        clean["target_count"] = n if n and n > 0 else 0
    if "provider" in data:
        if data["provider"] in PROVIDERS:
            clean["provider"] = data["provider"]
        else:
            errors["provider"] = "invalid"
    if "status" in data:
        if data["status"] in SURVEY_STATUSES:
            clean["status"] = data["status"]
        else:
            errors["status"] = "invalid"
    if "audienceFilter" in data:
        years = ((data["audienceFilter"] or {}).get("graduationYears")) or []
        numbers = []
        for y in years:
            n = to_int(y)
            if n is None:
                errors["audienceFilter"] = "invalid"
            else:
                numbers.append(str(n))
        clean["graduation_years"] = ",".join(numbers)
    if "questionsSchema" in data:
        if isinstance(data["questionsSchema"], list):
            clean["questions_schema"] = json.dumps(data["questionsSchema"], ensure_ascii=False)
        else:
            errors["questionsSchema"] = "must_be_list"
    for column in ("start_date", "end_date"):
        if clean.get(column) and not DATE_RE.match(clean[column]):
            errors[column] = "invalid_date"
    if errors:
        raise ApiError(422, "VALIDATION_ERROR", "Проверьте заполненные поля", errors)
    return clean


def survey_out(row):
    years = [int(y) for y in (row["graduation_years"] or "").split(",") if y.strip().isdigit()]
    out = {
        "id": row["id"], "title": row["title"], "description": row["description"],
        "provider": row["provider"], "externalFormId": row["external_form_id"],
        "formUrl": row["form_url"], "audienceFilter": {"graduationYears": years},
        "status": row["status"], "startDate": row["start_date"], "endDate": row["end_date"],
        "questionsSchema": json.loads(row["questions_schema"] or "[]"), "createdAt": row["created_at"],
        "audience": row["audience"], "targetCount": row["target_count"],
    }
    if "responses_count" in row:
        out["responsesCount"] = row["responses_count"]
    return out


_SURVEY_SELECT = ("SELECT s.*, (SELECT COUNT(*) FROM survey_responses r WHERE r.survey_id = s.id) "
                  "AS responses_count FROM surveys s")


def get_survey_row(sid):
    row = fetch_one(_SURVEY_SELECT + " WHERE s.id = ?", (sid,))
    if not row:
        raise ApiError(404, "NOT_FOUND", "Опрос не найден")
    return row


def get_survey(sid):
    return survey_out(get_survey_row(sid))


def list_surveys(query):
    status = query.get("status")
    if status in SURVEY_STATUSES:
        rows = fetch_all(_SURVEY_SELECT + " WHERE s.status = ? ORDER BY s.created_at DESC", (status,))
    else:
        rows = fetch_all(_SURVEY_SELECT + " ORDER BY s.created_at DESC")
    return {"items": [survey_out(r) for r in rows], "total": len(rows), "page": 1, "pageSize": len(rows)}


def create_survey(data, actor):
    clean = validate_survey(data, creating=True)
    clean.setdefault("provider", "internal")
    clean.setdefault("status", "draft")
    clean.setdefault("graduation_years", "")
    clean.setdefault("questions_schema", "[]")
    sid = new_id()
    clean.update({"id": sid, "created_by": actor["id"], "created_at": now_iso()})
    insert_row("surveys", clean)
    audit(actor, "create", "survey", sid, {"title": clean["title"]})
    return get_survey(sid)


def update_survey(sid, data, actor):
    get_survey_row(sid)
    clean = validate_survey(data, creating=False)
    update_row("surveys", sid, clean)
    audit(actor, "update", "survey", sid, {"fields": sorted(clean)})
    return get_survey(sid)


def delete_survey(sid, actor):
    get_survey_row(sid)
    run("DELETE FROM survey_responses WHERE survey_id = ?", (sid,))
    run("DELETE FROM surveys WHERE id = ?", (sid,))
    audit(actor, "delete", "survey", sid)


def survey_years(survey):
    if not survey:
        return []
    return [int(y) for y in (survey["graduation_years"] or "").split(",") if y.strip().isdigit()]


# ---------------------------------------------------------------- разбор ответов

# Подсказки для сопоставления вопроса анкеты (или заголовка CSV) с полем.
# Порядок важен: более точные подсказки идут раньше.
FORM_HINTS = [
    ("isBySpecialty", ("по специальности", "is_by_specialty")),
    ("fullName", ("фио", "фамилия имя", "полное имя", "имя и фамилия", "как вас зовут", "фамилия", "имя", "full_name", "fullname")),
    ("email", ("почт", "e-mail", "email")),
    ("phone", ("телефон", "phone")),
    ("groupName", ("групп", "group")),
    ("specialty", ("специальност", "specialty")),
    ("graduationYear", ("год выпуска", "graduation_year", "год", "year")),
    ("employmentType", ("тип занятости", "тип работы", "график", "employment_type")),
    ("status", ("статус", "занят", "status")),
    ("companyName", ("компани", "организаци", "место работы", "работодател", "company")),
    ("position", ("должност", "position")),
    ("salary", ("зарплат", "доход", "оклад", "salary")),
    ("consent", ("согласи", "consent")),
]


def map_form_answers(answers):
    """Превращает {вопрос: [ответ]} в {поле: значение} по подсказкам."""
    fields = {}
    for question, raw in answers.items():
        value = raw[0] if isinstance(raw, list) and raw else raw
        value = "" if value is None else str(value).strip()
        text = str(question).lower()
        for field, hints in FORM_HINTS:
            if field not in fields and any(h in text for h in hints):
                fields[field] = value
                break
    return fields


def canonical_from_fields(f):
    status = status_or_none(f.get("status"))
    employment = employment_from({
        "companyName": f.get("companyName"), "position": f.get("position"),
        "employmentType": f.get("employmentType"), "isBySpecialty": f.get("isBySpecialty"),
        "salary": f.get("salary"),
    }, status)
    return {
        "graduate": {
            "fullName": f.get("fullName") or "", "email": f.get("email") or "",
            "phone": f.get("phone") or None, "groupName": f.get("groupName") or None,
            "specialty": f.get("specialty") or None, "graduationYear": to_int(f.get("graduationYear")),
            "status": status,
        },
        "employment": employment,
        "consentPersonalData": to_bool(f.get("consent")),
    }


def canonical_from_api(body):
    g = body.get("graduate") or {}
    e = body.get("employment") or {}
    status = status_or_none(e.get("status") or g.get("status"))
    return {
        "graduate": {
            "fullName": g.get("fullName") or "", "email": g.get("email") or "",
            "phone": g.get("phone") or None, "groupName": g.get("groupName") or None,
            "specialty": g.get("specialty") or None, "graduationYear": to_int(g.get("graduationYear")),
            "status": status,
        },
        "employment": employment_from(e, status),
        "consentPersonalData": body.get("consentPersonalData") is True,
    }


_RESPONSE_SELECT = ("SELECT r.*, s.title AS survey_title FROM survey_responses r "
                    "LEFT JOIN surveys s ON s.id = r.survey_id")


def response_out(row):
    processed = json.loads(row["processed_payload"]) if row["processed_payload"] else None
    name = (processed or {}).get("graduate", {}).get("fullName")
    return {
        "id": row["id"], "surveyId": row["survey_id"], "surveyTitle": row["survey_title"],
        "graduateId": row["graduate_id"], "respondentIdentifier": row["respondent_identifier"],
        "name": name, "email": row["respondent_identifier"], "source": row["source"],
        "status": row["status"], "errorMessage": row["error_message"],
        "receivedAt": row["received_at"], "appliedAt": row["applied_at"],
        "processedPayload": processed, "rawPayload": json.loads(row["raw_payload"]),
    }


def get_response_row(rid):
    row = fetch_one(_RESPONSE_SELECT + " WHERE r.id = ?", (rid,))
    if not row:
        raise ApiError(404, "NOT_FOUND", "Ответ не найден")
    return row


def list_responses(query):
    page, size = paging(query)
    where, params = ["1 = 1"], []
    if query.get("surveyId"):
        where.append("r.survey_id = ?")
        params.append(query["surveyId"])
    if query.get("status") in RESPONSE_STATUSES:
        where.append("r.status = ?")
        params.append(query["status"])
    where_sql = " AND ".join(where)
    total = fetch_one(f"SELECT COUNT(*) AS n FROM survey_responses r WHERE {where_sql}", params)["n"]
    rows = fetch_all(f"{_RESPONSE_SELECT} WHERE {where_sql} ORDER BY r.received_at DESC LIMIT ? OFFSET ?",
                     params + [size, (page - 1) * size])
    return paged([response_out(r) for r in rows], total, page, size)


def get_response(rid):
    return response_out(get_response_row(rid))


def update_response(rid, data, actor):
    get_response_row(rid)
    changes = {}
    if "status" in data:
        if data["status"] not in RESPONSE_STATUSES:
            raise ApiError(422, "VALIDATION_ERROR", "Неизвестный статус", {"status": "invalid"})
        changes["status"] = data["status"]
        if data["status"] == "applied":
            changes["applied_at"] = now_iso()
    if "errorMessage" in data:
        changes["error_message"] = data["errorMessage"] or None
    update_row("survey_responses", rid, changes)
    audit(actor, "update", "survey_response", rid, {"status": changes.get("status")})
    return get_response(rid)


def record_failed(survey_id, source, raw, message):
    """Сохраняет неудачный ответ со статусом error, чтобы куратор мог проверить его вручную."""
    insert_row("survey_responses", {
        "id": new_id(), "survey_id": survey_id, "graduate_id": None, "respondent_identifier": None,
        "source": source, "raw_payload": json.dumps(raw, ensure_ascii=False, default=str),
        "processed_payload": None, "status": "error", "error_message": message, "received_at": now_iso(),
    })


def apply_submission(canon, source, raw, survey=None, actor=None):
    """Общая обработка любого ответа: проверка, создание/обновление выпускника и запись ответа."""
    g = canon["graduate"]
    if not canon["consentPersonalData"]:
        raise ApiError(422, "CONSENT_REQUIRED",
                       "Без согласия на обработку персональных данных анкета не принимается",
                       {"consentPersonalData": "required"})
    errors = {}
    if not g["fullName"]:
        errors["fullName"] = "required"
    email = g["email"].strip().lower()
    if email and not EMAIL_RE.match(email):
        errors["email"] = "invalid"
    years = survey_years(survey)
    if years and g["graduationYear"] not in years:
        raise ApiError(422, "NOT_IN_AUDIENCE", "Этот опрос предназначен для других годов выпуска",
                       {"graduationYear": "not_in_audience"})
    if errors:
        raise ApiError(422, "VALIDATION_ERROR", "Проверьте заполненные поля", errors)

    final_status = g["status"] or ("employed" if canon["employment"] else None)
    ts = now_iso()
    existing = fetch_one("SELECT * FROM graduates WHERE email = ? AND deleted_at IS NULL", (email,)) if email else None
    if existing:
        gid = existing["id"]
        changes = {"updated_at": ts, "consent_personal_data": 1}
        for key, column in [("fullName", "full_name"), ("phone", "phone"), ("groupName", "group_name"),
                            ("specialty", "specialty"), ("graduationYear", "graduation_year")]:
            if g.get(key):
                changes[column] = g[key]
        if final_status:
            changes["status"] = final_status
        update_row("graduates", gid, changes)
    else:
        gid = new_id()
        insert_row("graduates", {
            "id": gid, "full_name": g["fullName"], "email": email or None, "phone": g["phone"],
            "group_name": g["groupName"], "specialty": g["specialty"], "graduation_year": g["graduationYear"],
            "status": final_status or "student", "consent_personal_data": 1,
            "created_at": ts, "updated_at": ts,
        })

    rid = new_id()
    insert_row("survey_responses", {
        "id": rid, "survey_id": survey["id"] if survey else None, "graduate_id": gid,
        "respondent_identifier": email or None, "source": source,
        "raw_payload": json.dumps(raw, ensure_ascii=False, default=str),
        "processed_payload": json.dumps(canon, ensure_ascii=False),
        "status": "parsed", "received_at": ts,
    })
    set_current_employment(gid, canon["employment"], source_response_id=rid)
    run("UPDATE survey_responses SET status = 'applied', applied_at = ? WHERE id = ?", (now_iso(), rid))
    audit(actor, "receive_response", "survey_response", rid, {"source": source, "fullName": g["fullName"]})
    return {"responseId": rid, "graduateId": gid, "status": "applied", "receivedAt": ts}


def _require_active(survey):
    if survey["status"] != "active":
        raise ApiError(409, "SURVEY_NOT_ACTIVE", "Опрос сейчас не принимает ответы")


def process_public_submission(survey_id, body):
    """Публичная анкета выпускника (без входа в систему)."""
    survey = get_survey_row(survey_id)
    _require_active(survey)
    canon = canonical_from_api(body)
    try:
        return apply_submission(canon, "internal", body, survey=survey)
    except ApiError as e:
        record_failed(survey["id"], "internal", body, e.message)
        raise


def process_form_webhook(survey_id, body, source):
    """Приём ответов из Google Forms (через скрипт) или Яндекс Форм (через webhook)."""
    survey = get_survey_row(survey_id)
    _require_active(survey)
    answers = body.get("answers") or body.get("namedValues") or {}
    if not isinstance(answers, dict) or not answers:
        raise ApiError(422, "VALIDATION_ERROR", "Нет ответов: ожидается объект answers", {"answers": "required"})
    canon = canonical_from_fields(map_form_answers(answers))
    try:
        return apply_submission(canon, source, answers, survey=survey)
    except ApiError as e:
        record_failed(survey["id"], source, answers, e.message)
        raise


def import_graduates(body, actor):
    """Импорт CSV из ИС колледжа или из выгрузки Яндекс Форм. Возвращает отчёт по строкам."""
    source = body.get("sourceType") or "college"
    if source not in IMPORT_SOURCES:
        raise ApiError(422, "VALIDATION_ERROR", "Неизвестный источник", {"sourceType": "invalid"})
    text = str(body.get("csv") or "").lstrip("\ufeff")
    if not text.strip():
        raise ApiError(422, "VALIDATION_ERROR", "Файл пустой", {"csv": "required"})
    survey = get_survey_row(body["surveyId"]) if body.get("surveyId") else None

    first_line = text.split("\n", 1)[0]
    delimiter = ";" if first_line.count(";") > first_line.count(",") else ","
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    headers = reader.fieldnames or []
    field_for = {h: next(iter(map_form_answers({h: ""})), None) for h in headers}

    imported, total, errors = 0, 0, []
    for line_no, row in enumerate(reader, start=2):
        total += 1
        fields = {}
        for h in headers:
            field = field_for.get(h)
            value = (row.get(h) or "").strip()
            if field and value and field not in fields:
                fields[field] = value
        try:
            apply_submission(canonical_from_fields(fields), source, row, survey=survey, actor=actor)
            imported += 1
        except ApiError as e:
            errors.append({"line": line_no, "message": e.message, "fields": e.fields})
    audit(actor, "import", "graduates", None, {"source": source, "total": total, "imported": imported})
    return {"importedRows": imported, "totalRows": total, "errorRows": len(errors), "errors": errors[:100]}


# ---------------------------------------------------------------- отчёты и журнал

def employment_report(query=None):
    query = query or {}
    year = to_int(query.get("graduationYear"))
    where, params = ["deleted_at IS NULL"], []
    if year is not None:
        where.append("graduation_year = ?")
        params.append(year)
    grads = fetch_all(f"SELECT id, specialty, status FROM graduates WHERE {' AND '.join(where)}", params)
    total = len(grads)
    by_status = {st: 0 for st in GRADUATE_STATUSES}
    for g in grads:
        by_status[g["status"]] = by_status.get(g["status"], 0) + 1
    employed = by_status.get("employed", 0)

    cur_where, cur_params = ["e.is_current = 1", "g.status = 'employed'", "g.deleted_at IS NULL"], []
    if year is not None:
        cur_where.append("g.graduation_year = ?")
        cur_params.append(year)
    current = fetch_all(
        "SELECT g.specialty, e.is_by_specialty, e.salary, e.company_name FROM employments e "
        "JOIN graduates g ON g.id = e.graduate_id WHERE " + " AND ".join(cur_where), cur_params)

    groups = {}

    def group(name):
        name = name or "Не указана"
        return groups.setdefault(name, {"total": 0, "employed": 0, "bySpecialty": 0, "salaries": []})

    for g in grads:
        d = group(g["specialty"])
        d["total"] += 1
        if g["status"] == "employed":
            d["employed"] += 1
    for e in current:
        d = group(e["specialty"])
        if e["is_by_specialty"]:
            d["bySpecialty"] += 1
        if e["salary"]:
            d["salaries"].append(e["salary"])

    rows = []
    for name in sorted(groups):
        d = groups[name]
        rows.append({
            "specialty": name, "total": d["total"], "employed": d["employed"],
            "employmentRate": pct(d["employed"], d["total"]),
            "bySpecialtyRate": pct(d["bySpecialty"], d["employed"]),
            "averageSalary": round(sum(d["salaries"]) / len(d["salaries"])) if d["salaries"] else None,
        })

    salaries = [e["salary"] for e in current if e["salary"]]
    by_spec_count = sum(1 for e in current if e["is_by_specialty"])
    return {
        "total": total, "byStatus": by_status, "employed": employed,
        "employmentRate": pct(employed, total),
        "bySpecialtyCount": by_spec_count, "bySpecialtyRate": pct(by_spec_count, employed),
        "averageSalary": round(sum(salaries) / len(salaries)) if salaries else None,
        "employersCount": len({e["company_name"] for e in current if e["company_name"]}),
        "responsesTotal": fetch_one("SELECT COUNT(*) AS n FROM survey_responses")["n"],
        "bySpecialty": rows,
    }


def employment_report_csv(report):
    out = io.StringIO()
    writer = csv.writer(out, delimiter=";")
    writer.writerow(["Специальность", "Всего", "Трудоустроено", "Доля трудоустроенных, %",
                     "Работают по специальности, %", "Средняя зарплата, руб."])
    for r in report["bySpecialty"]:
        writer.writerow([r["specialty"], r["total"], r["employed"], r["employmentRate"],
                         r["bySpecialtyRate"], r["averageSalary"] if r["averageSalary"] is not None else ""])
    return "\ufeff" + out.getvalue()  # BOM, чтобы Excel правильно открыл русские буквы


def list_audit(query):
    page, size = paging(query)
    total = fetch_one("SELECT COUNT(*) AS n FROM audit_log")["n"]
    rows = fetch_all(
        "SELECT a.*, u.full_name AS user_name FROM audit_log a "
        "LEFT JOIN users u ON u.id = a.user_id "
        "ORDER BY a.created_at DESC, a.rowid DESC LIMIT ? OFFSET ?",
        [size, (page - 1) * size])
    items = [{
        "id": r["id"], "userName": r["user_name"], "action": r["action"],
        "entityType": r["entity_type"], "entityId": r["entity_id"],
        "details": json.loads(r["details"] or "{}"), "createdAt": r["created_at"],
    } for r in rows]
    return paged(items, total, page, size)


# ---------------------------------------------------------------- справочники

DIRECTORY_TYPES = ("specialties", "employers", "skills", "employmentTypes")
INTEGRATION_NAMES = [
    ("college", "ИС колледжа"),
    ("google", "Google Forms / Sheets"),
    ("yandex", "Yandex Forms"),
    ("notifications", "Email / SMS уведомления"),
]
INTEGRATION_STATUSES = ("Не подключено", "Настроено")


def _check_directory_type(dtype):
    if dtype not in DIRECTORY_TYPES:
        raise ApiError(404, "NOT_FOUND", "Справочник не найден")


def list_directory(dtype):
    _check_directory_type(dtype)
    rows = fetch_all("SELECT id, value FROM directories WHERE type = ? ORDER BY value", (dtype,))
    return {"items": rows, "total": len(rows), "page": 1, "pageSize": len(rows)}


def _directory_row(dtype, did):
    _check_directory_type(dtype)
    row = fetch_one("SELECT * FROM directories WHERE id = ? AND type = ?", (did, dtype))
    if not row:
        raise ApiError(404, "NOT_FOUND", "Значение не найдено")
    return row


def _clean_directory_value(data):
    value = str(data.get("value") or "").strip()
    if not value:
        raise ApiError(422, "VALIDATION_ERROR", "Введите значение", {"value": "required"})
    return value


def create_directory(dtype, data, actor):
    _check_directory_type(dtype)
    value = _clean_directory_value(data)
    if fetch_one("SELECT id FROM directories WHERE type = ? AND value = ?", (dtype, value)):
        raise ApiError(409, "DUPLICATE", "Такое значение уже есть")
    did = new_id()
    insert_row("directories", {"id": did, "type": dtype, "value": value, "created_at": now_iso()})
    audit(actor, "create", "directory", did, {"type": dtype, "value": value})
    return {"id": did, "value": value}


def update_directory(dtype, did, data, actor):
    _directory_row(dtype, did)
    value = _clean_directory_value(data)
    update_row("directories", did, {"value": value})
    audit(actor, "update", "directory", did, {"type": dtype, "value": value})
    return {"id": did, "value": value}


def delete_directory(dtype, did, actor):
    row = _directory_row(dtype, did)
    run("DELETE FROM directories WHERE id = ?", (did,))
    audit(actor, "delete", "directory", did, {"type": dtype, "value": row["value"]})


# ---------------------------------------------------------------- интеграции (без секретов)

def list_integrations():
    rows = fetch_all("SELECT provider, display_name, url, status FROM integrations ORDER BY provider")
    return {"items": rows, "total": len(rows), "page": 1, "pageSize": len(rows)}


def update_integration(provider, data, actor):
    if not fetch_one("SELECT provider FROM integrations WHERE provider = ?", (provider,)):
        raise ApiError(404, "NOT_FOUND", "Интеграция не найдена")
    changes = {}
    if "url" in data:
        changes["url"] = str(data["url"] or "").strip() or None
    if "status" in data:
        if data["status"] not in INTEGRATION_STATUSES:
            raise ApiError(422, "VALIDATION_ERROR", "Неизвестный статус", {"status": "invalid"})
        changes["status"] = data["status"]
    if changes:
        sets = ", ".join(f"{k} = ?" for k in changes)
        run(f"UPDATE integrations SET {sets} WHERE provider = ?", [*changes.values(), provider])
    audit(actor, "update", "integration", provider, {"fields": sorted(changes)})
    return next(i for i in list_integrations()["items"] if i["provider"] == provider)


# ---------------------------------------------------------------- прочие действия

def delete_response(rid, actor):
    get_response_row(rid)
    run("DELETE FROM survey_responses WHERE id = ?", (rid,))
    audit(actor, "delete", "survey_response", rid)


def delete_user(uid, actor):
    if uid == actor["id"]:
        raise ApiError(422, "SELF_DELETE", "Нельзя удалить собственную учётную запись")
    if not fetch_one("SELECT id FROM users WHERE id = ?", (uid,)):
        raise ApiError(404, "NOT_FOUND", "Пользователь не найден")
    run("DELETE FROM sessions WHERE user_id = ?", (uid,))
    run("DELETE FROM users WHERE id = ?", (uid,))
    audit(actor, "delete", "user", uid)


def update_profile(user, data):
    changes = {}
    if "fullName" in data:
        name = str(data["fullName"] or "").strip()
        if not name:
            raise ApiError(422, "VALIDATION_ERROR", "Введите имя", {"fullName": "required"})
        changes["full_name"] = name
    if "email" in data:
        email = str(data["email"] or "").strip().lower()
        if not EMAIL_RE.match(email):
            raise ApiError(422, "VALIDATION_ERROR", "Некорректный email", {"email": "invalid"})
        if fetch_one("SELECT id FROM users WHERE email = ? AND id != ?", (email, user["id"])):
            raise ApiError(409, "DUPLICATE", "Пользователь с таким email уже есть")
        changes["email"] = email
    update_row("users", user["id"], changes)
    audit(user, "update", "profile", user["id"], {"fields": sorted(changes)})
    return user_out(fetch_one("SELECT * FROM users WHERE id = ?", (user["id"],)))


def public_survey(sid):
    """Минимальные сведения об опросе для публичной анкеты (без внутренних полей)."""
    row = get_survey_row(sid)
    return {"id": row["id"], "title": row["title"], "description": row["description"],
            "status": row["status"], "startDate": row["start_date"], "endDate": row["end_date"]}


def ensure_initial_data():
    """Создаёт администратора, интеграции и типы занятости, если их ещё нет."""
    ensure_admin()
    for provider, name in INTEGRATION_NAMES:
        run("INSERT OR IGNORE INTO integrations (provider, display_name, url, status) VALUES (?, ?, NULL, ?)",
            (provider, name, "Не подключено"))
    if not fetch_one("SELECT id FROM directories WHERE type = 'employmentTypes' LIMIT 1"):
        for value in ("Полная", "Частичная", "Проектная", "Самозанятый"):
            insert_row("directories", {"id": new_id(), "type": "employmentTypes", "value": value,
                                       "created_at": now_iso()})
