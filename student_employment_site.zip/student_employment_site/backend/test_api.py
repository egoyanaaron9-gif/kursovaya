"""Тесты бекенда. Запуск: python test_api.py"""
import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from urllib.parse import quote
from http.server import ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "test.db")
os.environ["WEBHOOK_SECRET"] = "test-secret"
os.environ["ADMIN_EMAIL"] = "admin@test.ru"
os.environ["ADMIN_PASSWORD"] = "admin-pass-123"

import services  # noqa: E402
from server import Handler  # noqa: E402


class ApiTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        services.ensure_initial_data()
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.base = f"http://127.0.0.1:{cls.httpd.server_address[1]}/api/v1"
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()
        cls.admin = cls.login("admin@test.ru", "admin-pass-123")

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()

    @classmethod
    def call(cls, method, path, body=None, token=None, headers=None):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(cls.base + quote(path, safe="/?=&"), data=data, method=method)
        req.add_header("Content-Type", "application/json")
        if token:
            req.add_header("Authorization", f"Bearer {token}")
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        try:
            with urllib.request.urlopen(req) as r:
                raw, ctype, status = r.read(), r.headers.get("Content-Type", ""), r.status
        except urllib.error.HTTPError as e:
            raw, ctype, status = e.read(), e.headers.get("Content-Type", ""), e.code
        if "json" in ctype:
            return status, json.loads(raw.decode("utf-8"))
        return status, raw.decode("utf-8")

    @classmethod
    def login(cls, email, password):
        status, data = cls.call("POST", "/auth/login", {"email": email, "password": password})
        assert status == 200, data
        return data["accessToken"]

    # ------------------------------------------------------------ тесты

    def test_login_and_access(self):
        status, data = self.call("POST", "/auth/login", {"email": "admin@test.ru", "password": "wrong"})
        self.assertEqual(status, 401)
        self.assertEqual(data["error"]["code"], "INVALID_CREDENTIALS")

        status, data = self.call("GET", "/graduates")
        self.assertEqual(status, 401)

        status, data = self.call("GET", "/auth/me", token=self.admin)
        self.assertEqual(status, 200)
        self.assertEqual(data["role"], "admin")

    def test_graduate_crud_and_consent(self):
        status, data = self.call("POST", "/graduates",
                                 {"fullName": "Без Согласия", "email": "noconsent@test.ru"}, token=self.admin)
        self.assertEqual(status, 422)
        self.assertEqual(data["error"]["code"], "CONSENT_REQUIRED")

        status, grad = self.call("POST", "/graduates", {
            "fullName": "Сидорова Анна", "email": "Sidorova@Test.ru", "groupName": "ИС-21",
            "specialty": "Информационные системы", "graduationYear": 2025, "status": "student",
            "consentPersonalData": True,
        }, token=self.admin)
        self.assertEqual(status, 201)
        self.assertEqual(grad["email"], "sidorova@test.ru")
        gid = grad["id"]

        status, lst = self.call("GET", "/graduates?search=Сидорова&graduationYear=2025", token=self.admin)
        self.assertEqual(status, 200)
        self.assertEqual(lst["total"], 1)

        status, grad = self.call("PATCH", f"/graduates/{gid}", {
            "status": "Работаю",
            "employment": {"companyName": "ООО Технологии", "position": "Аналитик", "isBySpecialty": True,
                           "salary": 70000},
        }, token=self.admin)
        self.assertEqual(status, 200)
        self.assertEqual(grad["status"], "employed")
        self.assertEqual(grad["employment"]["companyName"], "ООО Технологии")

        status, _ = self.call("DELETE", f"/graduates/{gid}", token=self.admin)
        self.assertEqual(status, 200)
        status, _ = self.call("GET", f"/graduates/{gid}", token=self.admin)
        self.assertEqual(status, 404)

    def test_survey_public_submission_and_report(self):
        status, survey = self.call("POST", "/surveys", {
            "title": "Мониторинг 2026", "provider": "internal", "status": "active",
            "audienceFilter": {"graduationYears": [2026]},
        }, token=self.admin)
        self.assertEqual(status, 201)
        sid = survey["id"]

        body = {
            "graduate": {"fullName": "Иван Иванов", "email": "ivan@test.ru",
                         "groupName": "ИС-22", "specialty": "Информационные системы", "graduationYear": 2026},
            "employment": {"status": "employed", "companyName": "ООО Технологии", "position": "Аналитик",
                           "employmentType": "full_time", "isBySpecialty": True, "salary": 72000,
                           "currency": "RUB"},
            "consentPersonalData": True,
        }
        status, res = self.call("POST", f"/public/surveys/{sid}/responses", body)
        self.assertEqual(status, 201, res)
        self.assertEqual(res["status"], "applied")

        wrong_year = dict(body, graduate=dict(body["graduate"], graduationYear=2020, email="old@test.ru"))
        status, data = self.call("POST", f"/public/surveys/{sid}/responses", wrong_year)
        self.assertEqual(status, 422)
        self.assertEqual(data["error"]["code"], "NOT_IN_AUDIENCE")

        status, lst = self.call("GET", f"/survey-responses?surveyId={sid}", token=self.admin)
        self.assertEqual(status, 200)
        self.assertEqual(lst["total"], 2)  # одна успешная и одна с ошибкой
        statuses = sorted(r["status"] for r in lst["items"])
        self.assertEqual(statuses, ["applied", "error"])

        status, rep = self.call("GET", "/reports/employment", token=self.admin)
        self.assertEqual(status, 200)
        self.assertGreater(rep["employmentRate"], 0)

        status, csv_text = self.call("GET", "/reports/employment?format=csv", token=self.admin)
        self.assertEqual(status, 200)
        self.assertIn("Специальность", csv_text)

    def test_google_forms_webhook(self):
        status, survey = self.call("POST", "/surveys", {"title": "Google 2026", "status": "active",
                                                        "provider": "google_forms"}, token=self.admin)
        sid = survey["id"]
        answers = {
            "ФИО": ["Петров Пётр"],
            "Адрес электронной почты": ["petrov@test.ru"],
            "Группа": ["ИС-21"],
            "Специальность": ["Информационные системы"],
            "Год выпуска": ["2026"],
            "Ваш статус": ["Работаю"],
            "Название компании": ["ООО Ромашка"],
            "Должность": ["Программист"],
            "Зарплата, руб.": ["80000"],
            "Работаете по специальности?": ["Да"],
            "Согласие на обработку ПД": ["Да, согласен"],
        }
        url = f"/webhooks/google-forms/{sid}"
        status, data = self.call("POST", url, {"answers": answers})
        self.assertEqual(status, 401)

        status, data = self.call("POST", url, {"answers": answers},
                                 headers={"X-Webhook-Secret": "test-secret"})
        self.assertEqual(status, 201, data)
        self.assertEqual(data["status"], "applied")

        status, lst = self.call("GET", f"/survey-responses?surveyId={sid}", token=self.admin)
        item = lst["items"][0]
        self.assertEqual(item["source"], "google_forms")
        self.assertEqual(item["name"], "Петров Пётр")

    def test_csv_import_with_errors(self):
        csv_text = (
            "ФИО;Email;Группа;Специальность;Год выпуска;Статус;Компания;Согласие\n"
            "Смирнов Олег;smirnov@test.ru;ИС-23;Информационные системы;2026;Учусь;;Да\n"
            "Козлова Мария;kozlova@test.ru;ИС-23;Информационные системы;2026;Работаю;ООО Альфа;\n"
            "Фёдоров Иван;fedorov@test.ru;ИС-23;Информационные системы;2026;Работаю;ООО Бета;Да\n"
        )
        status, report = self.call("POST", "/imports/graduates",
                                   {"sourceType": "yandex_forms", "csv": csv_text}, token=self.admin)
        self.assertEqual(status, 201, report)
        self.assertEqual(report["totalRows"], 3)
        self.assertEqual(report["importedRows"], 2)
        self.assertEqual(report["errorRows"], 1)
        self.assertEqual(report["errors"][0]["line"], 3)

    def test_roles(self):
        status, _ = self.call("POST", "/users", {"fullName": "Куратор", "email": "curator@test.ru",
                                                 "role": "curator", "password": "curator-pass-1"}, token=self.admin)
        self.assertEqual(status, 201)
        curator = self.login("curator@test.ru", "curator-pass-1")

        status, data = self.call("GET", "/users", token=curator)
        self.assertEqual(status, 403)

        status, data = self.call("GET", "/graduates", token=curator)
        self.assertEqual(status, 200)

        status, data = self.call("POST", "/users", {"fullName": "Хакер", "email": "h@test.ru",
                                                    "role": "admin", "password": "long-enough-1"}, token=curator)
        self.assertEqual(status, 403)

        analyst_token_status, _ = self.call("POST", "/users", {"fullName": "Аналитик", "email": "an@test.ru",
                                                              "role": "analyst", "password": "analyst-pass-1"},
                                            token=self.admin)
        self.assertEqual(analyst_token_status, 201)
        analyst = self.login("an@test.ru", "analyst-pass-1")
        status, _ = self.call("GET", "/reports/employment", token=analyst)
        self.assertEqual(status, 200)
        status, _ = self.call("POST", "/graduates", {"fullName": "X", "consentPersonalData": True}, token=analyst)
        self.assertEqual(status, 403)

    def test_zz_audit_log_records_actions(self):
        status, data = self.call("GET", "/audit-log", token=self.admin)
        self.assertEqual(status, 200)
        self.assertGreater(data["total"], 0)


    def test_employment_is_updated_not_duplicated(self):
        status, grad = self.call("POST", "/graduates", {"fullName": "Повтор Работа", "email": "povtor@test.ru",
                                                        "graduationYear": 2026, "status": "Трудоустроен",
                                                        "consentPersonalData": True,
                                                        "employment": {"companyName": "ООО А", "salary": 50000}},
                                 token=self.admin)
        self.assertEqual(status, 201, grad)
        gid = grad["id"]
        self.call("PATCH", f"/graduates/{gid}", {"employment": {"companyName": "ООО Б", "salary": 60000}},
                  token=self.admin)
        status, grad = self.call("GET", f"/graduates/{gid}", token=self.admin)
        self.assertEqual(len(grad["employments"]), 1)
        self.assertEqual(grad["employment"]["companyName"], "ООО Б")
        self.call("PATCH", f"/graduates/{gid}", {"status": "Не трудоустроен", "employment": None}, token=self.admin)
        status, grad = self.call("GET", f"/graduates/{gid}", token=self.admin)
        self.assertIsNone(grad["employment"])

    def test_directories_and_integrations(self):
        status, data = self.call("GET", "/directories/employmentTypes", token=self.admin)
        self.assertEqual(status, 200)
        self.assertIn("Полная", [x["value"] for x in data["items"]])

        status, item = self.call("POST", "/directories/specialties", {"value": "Тестовая специальность"},
                                 token=self.admin)
        self.assertEqual(status, 201)
        status, _ = self.call("PATCH", f"/directories/specialties/{item['id']}", {"value": "Переименована"},
                              token=self.admin)
        self.assertEqual(status, 200)
        status, _ = self.call("DELETE", f"/directories/specialties/{item['id']}", token=self.admin)
        self.assertEqual(status, 200)
        status, _ = self.call("GET", "/directories/unknown", token=self.admin)
        self.assertEqual(status, 404)

        status, data = self.call("GET", "/integrations", token=self.admin)
        self.assertEqual(status, 200)
        providers = {i["provider"] for i in data["items"]}
        self.assertTrue({"college", "google", "yandex", "notifications"} <= providers)
        status, data = self.call("PATCH", "/integrations/google", {"url": "https://example.test/x",
                                                                   "status": "Настроено"}, token=self.admin)
        self.assertEqual(status, 200)
        self.assertEqual(data["status"], "Настроено")

    def test_profile_user_delete_and_public_survey(self):
        status, me = self.call("PATCH", "/auth/me", {"fullName": "Главный Админ"}, token=self.admin)
        self.assertEqual(status, 200)
        self.assertEqual(me["fullName"], "Главный Админ")

        status, u = self.call("POST", "/users", {"fullName": "Временный", "email": "temp@test.ru",
                                                 "role": "analyst", "password": "temp-pass-123"}, token=self.admin)
        self.assertEqual(status, 201)
        status, _ = self.call("DELETE", f"/users/{u['id']}", token=self.admin)
        self.assertEqual(status, 200)
        status, data = self.call("DELETE", f"/users/{me['id']}", token=self.admin)
        self.assertEqual(status, 422)

        status, survey = self.call("POST", "/surveys", {"title": "Публичный", "status": "active",
                                                        "audience": "Все", "targetCount": 10}, token=self.admin)
        self.assertEqual(survey["audience"], "Все")
        self.assertEqual(survey["targetCount"], 10)
        status, pub = self.call("GET", f"/public/surveys/{survey['id']}")
        self.assertEqual(status, 200)
        self.assertNotIn("provider", pub)
        self.assertEqual(pub["title"], "Публичный")

    def test_delete_response_and_year_filtered_report(self):
        status, survey = self.call("POST", "/surveys", {"title": "Для удаления", "status": "active"},
                                   token=self.admin)
        body = {"graduate": {"fullName": "Удаляемый", "email": "del@test.ru", "graduationYear": 2031,
                             "status": "Не трудоустроен"},
                "consentPersonalData": True}
        status, res = self.call("POST", f"/public/surveys/{survey['id']}/responses", body)
        self.assertEqual(status, 201)
        status, _ = self.call("DELETE", f"/survey-responses/{res['responseId']}", token=self.admin)
        self.assertEqual(status, 200)
        status, _ = self.call("GET", f"/survey-responses/{res['responseId']}", token=self.admin)
        self.assertEqual(status, 404)

        status, rep = self.call("GET", "/reports/employment?graduationYear=2031", token=self.admin)
        self.assertEqual(status, 200)
        self.assertEqual(rep["total"], 1)
        self.assertIn("averageSalary", rep)
        self.assertIn("employersCount", rep)



if __name__ == "__main__":
    unittest.main(verbosity=2)
