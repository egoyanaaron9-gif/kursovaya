'use strict';

const API_BASE = window.COLLEGE_API_BASE || 'http://127.0.0.1:8000/api/v1';
const TOKEN_KEY = 'collegeCareer.token';
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function deepClone(value){ return JSON.parse(JSON.stringify(value)); }
class ApiFailure extends Error {
  constructor(status, code, message, fields){ super(message); this.status=status; this.code=code; this.fields=fields||{}; }
}
function emptyState(){
  return {graduates:[],surveys:[],responses:[],users:[],audit:[],integrations:{},
    directories:{specialties:[],employers:[],skills:[],employmentTypes:[]},report:null,analytics:null};
}
const DIRECTORY_TYPES=['specialties','employers','skills','employmentTypes'];
const GRAD_UI={employed:'Трудоустроен',unemployed:'Не трудоустроен',continuing_education:'Продолжает обучение',student:'Студент выпускного курса',other:'Другое'};
const GRAD_API=Object.fromEntries(Object.entries(GRAD_UI).map(([k,v])=>[v,k]));
const SURVEY_UI={draft:'Черновик',active:'Активен',closed:'Завершён'};
const SURVEY_API=Object.fromEntries(Object.entries(SURVEY_UI).map(([k,v])=>[v,k]));
const RESP_UI={applied:'Обработано',parsed:'Проверка',received:'Проверка',error:'Ошибка'};
const RESP_API={'Обработано':'applied','Проверка':'parsed','Ошибка':'error'};
const ROLE_UI={admin:'Администратор',curator:'Сотрудник учебной части',analyst:'Аналитик / методист',director:'Руководство'};
const ROLE_API=Object.fromEntries(Object.entries(ROLE_UI).map(([k,v])=>[v,k]));
const AUDIT_ACTIONS={create:'Создание',update:'Изменение',delete:'Удаление',import:'Импорт CSV',receive_response:'Получена анкета'};
const AUDIT_OBJECTS={graduate:'Карточка выпускника',survey:'Опрос',survey_response:'Ответ на опрос',user:'Пользователь',directory:'Справочник',integration:'Интеграция',profile:'Профиль',graduates:'Выпускники'};
const FIELD_LABELS={fullName:'ФИО',email:'email',graduationYear:'год выпуска',consentPersonalData:'согласие на обработку ПД',password:'пароль',title:'название',status:'статус',role:'роль',value:'значение',csv:'файл',startDate:'дата начала',endDate:'дата окончания',audienceFilter:'аудитория',targetCount:'ожидаемое количество',provider:'провайдер',url:'адрес'};

async function api(method,path,body,options={}){
  const auth=options.auth!==false;
  const headers={'Content-Type':'application/json'};
  if(auth&&token) headers.Authorization=`Bearer ${token}`;
  let response;
  try{
    response=await fetch(API_BASE+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
  }catch(error){
    throw new ApiFailure(0,'NETWORK','Нет связи с сервером. Запустите start.bat и проверьте, что сервер API работает.');
  }
  const text=await response.text();
  let data=null;
  try{ data=text?JSON.parse(text):null; }catch(error){ data=null; }
  if(!response.ok){
    const info=(data&&data.error)||{};
    if(response.status===401&&auth) handleSessionExpired();
    throw new ApiFailure(response.status,info.code||'ERROR',info.message||`Ошибка сервера (${response.status})`,info.fields||{});
  }
  return data;
}
async function fetchAll(path){
  const items=[]; let page=1;
  for(;;){
    const sep=path.includes('?')?'&':'?';
    const data=await api('GET',`${path}${sep}page=${page}&pageSize=100`);
    items.push(...data.items);
    if(!data.items.length||items.length>=data.total) break;
    page+=1;
  }
  return items;
}
function settle(promise,fallback){
  return promise.catch(error=>{
    if(error instanceof ApiFailure&&error.status===401) throw error;
    console.warn(error);
    return fallback;
  });
}
function emptyReport(){
  return {total:0,employed:0,employmentRate:0,bySpecialtyRate:0,responsesTotal:0,averageSalary:null,employersCount:0,byStatus:{},bySpecialty:[]};
}
function errorText(error){
  if(!(error instanceof ApiFailure)) return (error&&error.message)||'Неизвестная ошибка';
  const names=Object.keys(error.fields||{}).map(key=>FIELD_LABELS[key]||key);
  return names.length?`${error.message}: ${names.join(', ')}`:error.message;
}
function handleError(error){
  if(error instanceof ApiFailure&&error.status===401) return;
  toast(errorText(error));
}
function yesNo(value){ return value===null||value===undefined?'':(value?'Да':'Нет'); }
function gradFromApi(g){
  const e=g.employment||{};
  return {id:g.id,fullName:g.fullName||'',email:g.email||'',phone:g.phone||'',groupName:g.groupName||'',
    specialty:g.specialty||'',graduationYear:g.graduationYear||'',status:GRAD_UI[g.status]||'Другое',
    companyName:e.companyName||'',position:e.position||'',employmentType:e.employmentType||'',
    isBySpecialty:yesNo(e.isBySpecialty),salary:e.salary??'',consent:g.consentPersonalData};
}
function surveyFromApi(s){
  return {id:s.id,title:s.title,description:s.description||'',status:SURVEY_UI[s.status]||'Черновик',
    startDate:s.startDate||'',endDate:s.endDate||'',audience:s.audience||'',targetCount:s.targetCount||0,
    questions:s.questionsSchema||[],responsesCount:s.responsesCount||0};
}
function respFromApi(r){
  const p=r.processedPayload||{}; const e=p.employment||{};
  return {id:r.id,graduateId:r.graduateId||'',name:r.name||r.respondentIdentifier||'Без имени',email:r.email||'',
    surveyId:r.surveyId||'',surveyTitle:r.surveyTitle||'Общая анкета выпускника',
    date:(r.receivedAt||'').slice(0,10),status:RESP_UI[r.status]||'Проверка',
    company:e.companyName||'',position:e.position||'',salary:e.salary??'',bySpecialty:yesNo(e.isBySpecialty),
    errorMessage:r.errorMessage||''};
}
function userFromApi(u){
  return {id:u.id,name:u.fullName,email:u.email,role:ROLE_UI[u.role]||u.role,roleCode:u.role,status:u.isActive?'Активен':'Отключён'};
}
function auditFromApi(a){
  const d=a.details||{};
  const text=Object.entries(d).map(([k,v])=>`${k}: ${Array.isArray(v)?v.join(', '):v}`).join('; ');
  return {id:a.id,date:new Date(a.createdAt).toLocaleString('ru-RU'),
    action:AUDIT_ACTIONS[a.action]||a.action,object:AUDIT_OBJECTS[a.entityType]||a.entityType,
    details:[a.userName,text].filter(Boolean).join(' · ')};
}
function gradToApi(values,isNew){
  const employed=values.status==='Трудоустроен';
  const body={
    fullName:values.fullName,email:values.email,phone:values.phone||null,groupName:values.groupName||null,
    specialty:values.specialty||null,graduationYear:values.graduationYear?Number(values.graduationYear):null,
    status:GRAD_API[values.status]||'other',
    employment:employed?{companyName:values.companyName||null,position:values.position||null,
      employmentType:values.employmentType||null,
      isBySpecialty:values.isBySpecialty==='Да'?true:values.isBySpecialty==='Нет'?false:null,
      salary:values.salary?Number(values.salary):null}:null
  };
  if(isNew) body.consentPersonalData=values.consent==='Да';
  return body;
}
function surveyToApi(values){
  return {title:values.title,description:values.description||'',audience:values.audience||'',
    status:SURVEY_API[values.status]||'draft',startDate:values.startDate||null,endDate:values.endDate||null,
    targetCount:Number(values.targetCount)||0,
    questionsSchema:(values.questionsText||'').split('\n').map(x=>x.trim()).filter(Boolean)};
}
function userToApi(values){
  const body={fullName:values.name,email:values.email,role:ROLE_API[values.role]||'curator',isActive:values.status==='Активен'};
  if(values.password) body.password=values.password;
  return body;
}
function directoryValues(type){ return (state.directories[type]||[]).map(x=>x.value); }
function confirmDelete(label){ return confirm(`Удалить запись «${label}»? Это действие нельзя отменить.`); }
function analyticsQuery(){
  const year=$('#analyticsYear')?.value;
  return year?`?graduationYear=${encodeURIComponent(year)}`:'';
}

function showLogin(message=''){
  const backdrop=$('#loginBackdrop');
  if(!backdrop) return;
  backdrop.hidden=false;
  $('#loginError').textContent=message;
  setTimeout(()=>$('#loginEmail')?.focus(),40);
}
function hideLogin(){
  const backdrop=$('#loginBackdrop');
  if(backdrop) backdrop.hidden=true;
  $('#loginError').textContent='';
}
function handleSessionExpired(){
  if(!token) return;
  token=null; me=null; sessionStorage.removeItem(TOKEN_KEY);
  state=emptyState(); closeModal(); renderAll();
  showLogin('Сессия истекла. Войдите снова.');
}
function setConnection(ok){
  const el=$('.local-indicator');
  if(el) el.innerHTML=ok?'<i></i> Сервер подключён':'<i></i> Нет связи с сервером';
}
function defaultPage(role){
  return role==='analyst'||role==='director'?'analytics':role==='admin'?'integrations':'dashboard';
}
async function submitLogin(event){
  event.preventDefault();
  const email=$('#loginEmail').value.trim();
  const password=$('#loginPassword').value;
  const button=$('#loginSubmit');
  button.disabled=true; $('#loginError').textContent='';
  try{
    const data=await api('POST','/auth/login',{email,password},{auth:false});
    token=data.accessToken;
    sessionStorage.setItem(TOKEN_KEY,token);
    $('#loginPassword').value='';
    await startSession();
  }catch(error){
    $('#loginError').textContent=errorText(error);
  }finally{
    button.disabled=false;
  }
}
async function startSession(){
  me=await api('GET','/auth/me');
  setRoleLabel(); hideLogin(); setConnection(true);
  await loadAll();
  const initial=currentHashPage();
  navigate(initial&&initial!=='dashboard'&&pageNames[initial]?initial:defaultPage(me.role),false);
  renderAll();
}
async function logout(){
  try{ if(token) await api('POST','/auth/logout'); }catch(error){ /* сессия всё равно закрывается */ }
  token=null; me=null; sessionStorage.removeItem(TOKEN_KEY);
  state=emptyState(); closeModal(); renderAll();
  showLogin('Вы вышли из системы.');
}
async function loadAll(){
  const [graduates,surveys,responses,users,audit,report,analytics,integrations,directories]=await Promise.all([
    settle(fetchAll('/graduates'),[]),
    settle(fetchAll('/surveys'),[]),
    settle(fetchAll('/survey-responses'),[]),
    settle(api('GET','/users').then(d=>d.items),[]),
    settle(fetchAll('/audit-log'),[]),
    settle(api('GET','/reports/employment'),null),
    settle(api('GET',`/reports/employment${analyticsQuery()}`),null),
    settle(api('GET','/integrations').then(d=>d.items),[]),
    Promise.all(DIRECTORY_TYPES.map(type=>settle(api('GET',`/directories/${type}`).then(d=>d.items),[]))),
  ]);
  state.graduates=graduates.map(gradFromApi);
  state.surveys=surveys.map(surveyFromApi);
  state.responses=responses.map(respFromApi);
  state.users=users.map(userFromApi);
  state.audit=audit.map(auditFromApi);
  state.report=report||emptyReport();
  state.analytics=analytics||state.report;
  state.integrations=Object.fromEntries(integrations.map(i=>[i.provider,{name:i.display_name,url:i.url||'',status:i.status}]));
  DIRECTORY_TYPES.forEach((type,index)=>{ state.directories[type]=directories[index]; });
}
async function reload(message){
  try{
    await loadAll(); renderAll();
    if(message) toast(message);
  }catch(error){ handleError(error); }
}

let token = sessionStorage.getItem(TOKEN_KEY);
let me = null;
let state = emptyState();
let activeDirectory = 'specialties';
let modalContext = null;
let toastTimer = null;

function uid(prefix='id'){ return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`; }
function esc(value){ return String(value ?? '').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function formatMoney(value){ const n=Number(value); return Number.isFinite(n)&&n>0?new Intl.NumberFormat('ru-RU').format(n)+' ₽':'—'; }
function formatDate(value){ if(!value) return '—'; const d=new Date(value+'T00:00:00'); return Number.isNaN(d.getTime())?esc(value):d.toLocaleDateString('ru-RU'); }
function initials(name){ return String(name||'?').trim().split(/\s+/).slice(0,2).map(part=>part[0]||'').join('').toUpperCase(); }
function statusClass(status){ if(['Трудоустроен','Обработано','Активен','Завершён','Подключено'].includes(status)) return ''; if(['Проверка','Студент выпускного курса','Продолжает обучение','Не подключено','Черновик'].includes(status)) return 'wait'; return 'bad'; }
function statusBadge(status){ return `<span class="status ${statusClass(status)}">${esc(status||'Не указан')}</span>`; }
function toast(message){ const el=$('#toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),3000); }
async function commit(message){ await reload(message); }
function emptyRow(colspan,message){ return `<tr><td colspan="${colspan}"><div class="empty-state">${esc(message)}</div></td></tr>`; }

const pageNames={dashboard:'Главная',students:'Студенты и выпускники',surveys:'Опросы и анкеты',responses:'Ответы на опросы',analytics:'Аналитика и отчёты',directories:'Справочники',users:'Пользователи и роли',integrations:'Интеграции',imports:'Импорт и журнал',graduate:'Анкета выпускника'};
function currentHashPage(){ const raw=location.hash.replace(/^#/,''); return (raw.split('?')[0]||'dashboard'); }
function navigate(page,writeHash=true){
  if(!pageNames[page]) page='dashboard';
  if(page!=='graduate'&&!me&&!token) showLogin();
  $$('.page').forEach(el=>el.classList.toggle('active',el.id===`page-${page}`));
  $$('.nav-link').forEach(el=>el.classList.toggle('active',el.dataset.page===page));
  $('#breadcrumb').textContent=pageNames[page];
  $('#sidebar').classList.remove('open');
  if(writeHash && currentHashPage()!==page) history.pushState({page},'',`#${page}`);
  if(page==='graduate') populateGraduateSurveys();
}
const roleLabels={curator:'Сотрудник учебной части',admin:'Администратор',analyst:'Аналитик / методист',director:'Руководство',graduate:'Выпускник'};
const roleDefaults={curator:{name:'Александр Куратор',email:'curator@college.local'},admin:{name:'Администратор системы',email:'admin@college.local'},analyst:{name:'Ольга Смирнова',email:'analyst@college.local'},director:{name:'Директор колледжа',email:'director@college.local'},graduate:{name:'Пользователь',email:''}};
function setRoleLabel(){
  const name=me?.fullName||'Пользователь';
  $('#profileAvatar').textContent=initials(name)||'П';
  $('#profileName').textContent=name;
  $('#profileRole').textContent=roleLabels[me?.role]||'Пользователь';
  $('#profileName').title='Нажмите, чтобы открыть профиль';
  const select=$('#roleSelect');
  if(me&&[...select.options].some(o=>o.value===me.role)) select.value=me.role;
  select.disabled=true;
  select.title='Роль назначает администратор';
}
function openProfile(){
  if(!me) return;
  const name=me.fullName||''; const email=me.email||'';
  const roleLabel=roleLabels[me.role]||'Пользователь';
  const content=`<div class="profile-modal-intro"><div class="profile-modal-avatar">${esc(initials(name)||'П')}</div><div><strong>${esc(name)}</strong><span>${esc(roleLabel)}</span></div></div><div class="modal-form-grid"><div class="modal-field"><label for="profileEditName">ФИО</label><input id="profileEditName" value="${esc(name)}"></div><div class="modal-field"><label for="profileEditEmail">Email</label><input id="profileEditEmail" type="email" value="${esc(email)}"></div></div><p class="help-note profile-help">Роль назначает администратор. Здесь можно изменить только имя и email.</p>`;
  showModal('Профиль пользователя',content,`<button class="btn btn-secondary" type="button" data-action="logout">Выйти</button><button class="btn btn-secondary" type="button" data-action="modal-close">Закрыть</button><button class="btn" type="button" data-action="save-profile">Сохранить изменения</button>`,'МОЯ УЧЁТНАЯ ЗАПИСЬ');
}
async function saveProfile(){
  const name=$('#profileEditName')?.value.trim();
  const email=$('#profileEditEmail')?.value.trim()||'';
  if(!name){toast('Введите имя пользователя');$('#profileEditName')?.focus();return;}
  me=await api('PATCH','/auth/me',{fullName:name,email});
  setRoleLabel(); closeModal();
  await reload('Профиль обновлён');
}
function renderDashboard(){
  const r=state.report||emptyReport();
  const total=r.total, employed=r.employed, percent=r.employmentRate;
  $('#kpi-total').textContent=total;
  $('#kpi-employed').textContent=employed;
  $('#kpi-employed-share').textContent=`${percent}% от записей`;
  $('#kpi-specialty').textContent=`${r.bySpecialtyRate}%`;
  $('#kpi-responses').textContent=r.responsesTotal;
  $('#donutPercent').textContent=`${percent}%`;
  $('#employmentDonut').style.background=`conic-gradient(var(--blue) ${percent*3.6}deg, #e9eef6 ${percent*3.6}deg 360deg)`;
  const notEmployed=total-employed;
  $('#employmentLegend').innerHTML=`<div class="legend-item"><i class="legend-dot"></i><div>Трудоустроены<strong>${employed}</strong></div></div><div class="legend-item"><i class="legend-dot pale"></i><div>Другой статус<strong>${notEmployed}</strong></div></div>`;
  const active=state.surveys.filter(s=>s.status==='Активен');
  $('#dashboardSurveys').innerHTML=active.length?active.slice(0,4).map(s=>`<div class="compact-item"><div><strong>${esc(s.title)}</strong><small>${esc(s.audience||'Аудитория не задана')}</small></div><span class="compact-percent">${s.responsesCount||0}</span></div>`).join(''):'<div class="empty-state">Активных опросов нет</div>';
  $('#dashboardRecent').innerHTML=state.responses.slice(0,5).map(x=>`<tr><td><div class="person-cell"><div class="mini-avatar">${esc(initials(x.name))}</div><div><strong>${esc(x.name)}</strong><small>${esc(x.email||'')}</small></div></div></td><td>${esc(x.surveyTitle||'—')}</td><td>${formatDate(x.date)}</td><td>${statusBadge(x.status)}</td><td><button class="actions-link" data-action="view-response" data-id="${esc(x.id)}">Открыть</button></td></tr>`).join('')||emptyRow(5,'Ответов пока нет');
}
function renderStudents(){
  const q=($('#studentSearch')?.value||'').trim().toLowerCase();
  const year=$('#yearFilter')?.value||''; const status=$('#statusFilter')?.value||'';
  const rows=state.graduates.filter(g=>{
    const text=[g.fullName,g.email,g.groupName,g.specialty,g.companyName].join(' ').toLowerCase();
    return (!q||text.includes(q))&&(!year||String(g.graduationYear)===year)&&(!status||g.status===status);
  });
  $('#studentRows').innerHTML=rows.map(g=>`<tr><td><div class="person-cell"><div class="mini-avatar">${esc(initials(g.fullName))}</div><div><strong>${esc(g.fullName)}</strong><small>${esc(g.email||'Нет email')}</small></div></div></td><td>${esc(g.groupName||'—')}</td><td>${esc(g.specialty||'—')}</td><td>${esc(g.graduationYear||'—')}</td><td>${statusBadge(g.status)}</td><td><div class="table-actions"><button class="actions-link" data-action="view-student" data-id="${esc(g.id)}">Карточка</button><button class="actions-link" data-action="edit-student" data-id="${esc(g.id)}">Изменить</button><button class="actions-link danger-link" data-action="delete-student" data-id="${esc(g.id)}">Удалить</button></div></td></tr>`).join('')||emptyRow(6,'По заданным условиям записи не найдены');
  $('#studentCount').textContent=`Показано ${rows.length} из ${state.graduates.length} записей. Данные хранятся на сервере.`;
}

function renderSurveys(){
  $('#surveyGrid').innerHTML=state.surveys.map(s=>{
    const received=state.responses.filter(r=>r.surveyId===s.id).length;
    const expected=Math.max(Number(s.targetCount)||0,received,1);
    const pct=Math.min(100,Math.round(received/expected*100));
    return `<article class="survey-card"><div>${statusBadge(s.status)}</div><h3>${esc(s.title)}</h3><p>${esc(s.description||'Описание не добавлено')}</p><div class="survey-meta"><span>${formatDate(s.startDate)} — ${formatDate(s.endDate)}</span><strong>${received} ответов</strong></div><div class="progress"><span style="width:${pct}%"></span></div><div class="survey-meta"><span>${esc(s.audience||'Аудитория не задана')}</span><strong>${pct}%</strong></div><div class="survey-actions"><button class="btn btn-secondary" data-action="survey-results" data-id="${esc(s.id)}">Результаты</button><button class="btn btn-quiet" data-action="edit-survey" data-id="${esc(s.id)}">Настроить</button><button class="btn btn-quiet" data-action="survey-link" data-id="${esc(s.id)}">Ссылка</button><button class="btn btn-quiet" data-action="delete-survey" data-id="${esc(s.id)}" aria-label="Удалить опрос">Удалить</button></div></article>`;
  }).join('')||'<div class="panel empty-state">Опросов пока нет. Нажмите «Создать опрос».</div>';
}

function populateResponseFilters(){
  const select=$('#responseSurveyFilter'); const current=select.value;
  select.innerHTML='<option value="">Все опросы</option>'+state.surveys.map(s=>`<option value="${esc(s.id)}">${esc(s.title)}</option>`).join('');
  if(state.surveys.some(s=>s.id===current)) select.value=current;
}
function renderResponses(){
  populateResponseFilters();
  const q=($('#responseSearch')?.value||'').trim().toLowerCase(); const survey=$('#responseSurveyFilter')?.value||''; const status=$('#responseStatus')?.value||'';
  const rows=state.responses.filter(r=>(!q||`${r.name} ${r.email||''}`.toLowerCase().includes(q))&&(!survey||r.surveyId===survey)&&(!status||r.status===status)).sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  $('#responseRows').innerHTML=rows.map(r=>`<tr><td><div class="person-cell"><div class="mini-avatar">${esc(initials(r.name))}</div><div><strong>${esc(r.name)}</strong><small>${esc(r.email||'')}</small></div></div></td><td>${esc(r.surveyTitle||'—')}</td><td>${formatDate(r.date)}</td><td>${statusBadge(r.status)}</td><td><button class="actions-link" data-action="view-response" data-id="${esc(r.id)}">Просмотр →</button></td></tr>`).join('')||emptyRow(5,'Ответы не найдены');
  $('#responseCount').textContent=`Найдено ответов: ${rows.length}`;
}

function fillYearFilters(){
  const current=new Date().getFullYear();
  const years=[];
  for(let y=current+1;y>=2015;y--) years.push(String(y));
  const options='<option value="">Все годы</option>'+years.map(y=>`<option value="${y}">${y}</option>`).join('');
  ['yearFilter','analyticsYear'].forEach(id=>{const el=$(`#${id}`);const val=el.value;el.innerHTML=options;if(years.includes(val))el.value=val;});
  const importSurvey=$('#importSurvey');
  if(importSurvey){
    const prev=importSurvey.value;
    importSurvey.innerHTML='<option value="">Без привязки к опросу</option>'+state.surveys.map(s=>`<option value="${esc(s.id)}">${esc(s.title)}</option>`).join('');
    if(state.surveys.some(s=>s.id===prev)) importSurvey.value=prev;
  }
}
function renderAnalytics(){
  const a=state.analytics||state.report;
  if(!a) return;
  $('#analyticsEmployment').textContent=`${a.employmentRate}%`;
  $('#analyticsSpecialty').textContent=`${a.bySpecialtyRate}%`;
  $('#analyticsSalary').textContent=a.averageSalary?formatMoney(a.averageSalary):'—';
  $('#analyticsEmployers').textContent=a.employersCount;
  const entries=(a.bySpecialty||[]).slice().sort((x,y)=>y.total-x.total);
  $('#specialtyBars').innerHTML=entries.length?entries.map(v=>`<div><div class="bar-row-top"><span>${esc(v.specialty)} (${v.employed}/${v.total})</span><strong>${v.employmentRate}%</strong></div><div class="bar-track"><span style="width:${v.employmentRate}%"></span></div></div>`).join(''):'<div class="empty-state">Нет данных для построения отчёта</div>';
  $('#statusBreakdown').innerHTML=Object.entries(GRAD_UI).map(([key,label])=>`<div class="breakdown-row"><span>${esc(label)}</span><strong>${(a.byStatus||{})[key]||0}</strong></div>`).join('');
}
const directoryNames={specialties:'Специальности',employers:'Организации',skills:'Профессиональные навыки',employmentTypes:'Типы занятости'};
function renderDirectories(){
  activeDirectory=$('#directoryType').value||activeDirectory;
  const items=state.directories[activeDirectory]||[];
  $('#directoryCount').textContent=`Записей: ${items.length}`;
  $('#directoryRows').innerHTML=items.map(item=>`<tr><td>${esc(item.value)}</td><td><div class="table-actions"><button class="actions-link" data-action="edit-directory" data-id="${esc(item.id)}">Изменить</button><button class="actions-link danger" data-action="delete-directory" data-id="${esc(item.id)}">Удалить</button></div></td></tr>`).join('')||emptyRow(2,'Значений пока нет');
}
const roleOptions=['Администратор','Сотрудник учебной части','Аналитик / методист','Руководство'];
function renderUsers(){
  $('#userRows').innerHTML=state.users.map(u=>`<tr><td><div class="person-cell"><div class="mini-avatar">${esc(initials(u.name))}</div><div><strong>${esc(u.name)}</strong></div></div></td><td>${esc(u.email)}</td><td>${esc(u.role)}</td><td>${statusBadge(u.status)}</td><td><div class="table-actions"><button class="actions-link" data-action="edit-user" data-id="${esc(u.id)}">Изменить</button><button class="actions-link" data-action="toggle-user" data-id="${esc(u.id)}">${u.status==='Активен'?'Отключить':'Активировать'}</button><button class="actions-link danger-link" data-action="delete-user" data-id="${esc(u.id)}">Удалить</button></div></td></tr>`).join('')||emptyRow(5,'Пользователей пока нет');
}

function renderIntegrations(){
  const descriptions={college:'Импорт базовых сведений о студентах и выпускниках из внутренней ИС колледжа.',google:'Приём результатов Google Forms и Google Sheets.',yandex:'Приём результатов Яндекс Форм.',notifications:'Отправка приглашений, напоминаний и уведомлений.'};
  const icons={college:'▦',google:'G',yandex:'Я',notifications:'✉'};
  $('#integrationGrid').innerHTML=Object.entries(state.integrations).map(([key,v])=>`<article class="integration-card"><div class="integration-head"><div class="mini-avatar">${icons[key]||'⇄'}</div>${statusBadge(v.status||'Не подключено')}</div><h3>${esc(v.name)}</h3><p>${esc(descriptions[key]||'Внешняя интеграция')}</p><div class="muted">${v.url?`Адрес: ${esc(v.url)}`:'Адрес сервиса не задан'}</div><button class="btn btn-secondary" data-action="edit-integration" data-id="${esc(key)}">Настроить параметры</button></article>`).join('');
}

function renderAudit(){
  $('#auditRows').innerHTML=state.audit.map(a=>`<tr><td>${esc(a.date)}</td><td>${esc(a.action)}</td><td>${esc(a.object)}</td><td>${esc(a.details)}</td></tr>`).join('')||emptyRow(4,'Записей в журнале пока нет');
}
async function populateGraduateSurveys(){
  const select=$('#gradSurvey');
  if(!select) return;
  const previous=select.value;
  const params=new URLSearchParams(location.hash.split('?')[1]||'');
  const wanted=params.get('survey')||previous;
  let options=[];
  if(me){
    options=state.surveys.filter(s=>s.status==='Активен').map(s=>({id:s.id,title:s.title}));
  }else if(wanted){
    try{
      const survey=await api('GET',`/public/surveys/${encodeURIComponent(wanted)}`,undefined,{auth:false});
      if(survey.status==='active') options=[{id:survey.id,title:survey.title}];
    }catch(error){ options=[]; }
  }
  select.innerHTML='<option value="">Выберите опрос</option>'+options.map(o=>`<option value="${esc(o.id)}">${esc(o.title)}</option>`).join('');
  if(options.some(o=>o.id===wanted)) select.value=wanted;
  if(!options.length&&wanted&&!me) toast('Опрос недоступен или закрыт');
}
function renderAll(){fillYearFilters();renderDashboard();renderStudents();renderSurveys();renderResponses();renderAnalytics();renderDirectories();renderUsers();renderIntegrations();renderAudit();populateGraduateSurveys();}

function fieldHTML(field,data={}){
  const value=data[field.name]??field.value??'';
  const required=field.required?'required':'';
  const cls=field.full?'modal-field full':'modal-field';
  if(field.type==='select'){
    const options=(field.options||[]).map(opt=>{const v=typeof opt==='string'?opt:opt.value;const label=typeof opt==='string'?opt:opt.label;return `<option value="${esc(v)}" ${String(v)===String(value)?'selected':''}>${esc(label)}</option>`;}).join('');
    return `<div class="${cls}"><label for="f-${esc(field.name)}">${esc(field.label)}${field.required?' *':''}</label><select id="f-${esc(field.name)}" name="${esc(field.name)}" ${required}><option value="">Выберите</option>${options}</select></div>`;
  }
  if(field.type==='textarea') return `<div class="${cls}"><label for="f-${esc(field.name)}">${esc(field.label)}${field.required?' *':''}</label><textarea id="f-${esc(field.name)}" name="${esc(field.name)}" placeholder="${esc(field.placeholder||'')}" ${required}>${esc(value)}</textarea></div>`;
  return `<div class="${cls}"><label for="f-${esc(field.name)}">${esc(field.label)}${field.required?' *':''}</label><input id="f-${esc(field.name)}" name="${esc(field.name)}" type="${esc(field.type||'text')}" value="${esc(value)}" placeholder="${esc(field.placeholder||'')}" ${field.min!==undefined?`min="${field.min}"`:''} ${field.max!==undefined?`max="${field.max}"`:''} ${required}></div>`;
}
function showModal(title,content,footer,eyebrow='УПРАВЛЕНИЕ ДАННЫМИ'){
  $('#modalTitle').textContent=title;$('#modalEyebrow').textContent=eyebrow;$('#modalContent').innerHTML=content;$('#modalFooter').innerHTML=footer;
  $('#modalBackdrop').classList.add('open');$('#modalBackdrop').setAttribute('aria-hidden','false');
  const focus=$('#modalContent input, #modalContent select, #modalContent textarea');if(focus) setTimeout(()=>focus.focus(),40);
}
function closeModal(){ $('#modalBackdrop').classList.remove('open');$('#modalBackdrop').setAttribute('aria-hidden','true');modalContext=null; }
function openEntityForm(type,id=null){
  const collection={student:'graduates',survey:'surveys',user:'users'}[type];
  const item=id&&collection?state[collection].find(x=>x.id===id):null;
  if(id&&!item){toast('Запись не найдена');return;}
  let fields=[];
  if(type==='student') fields=[
    {name:'fullName',label:'ФИО',required:true},{name:'email',label:'Email',type:'email',required:true},{name:'phone',label:'Телефон'},
    {name:'groupName',label:'Группа'},{name:'specialty',label:'Специальность'},{name:'graduationYear',label:'Год выпуска',type:'number',min:2000,max:2100,required:true},
    {name:'status',label:'Статус',type:'select',required:true,options:['Трудоустроен','Не трудоустроен','Продолжает обучение','Студент выпускного курса','Другое']},
    {name:'companyName',label:'Организация'},{name:'position',label:'Должность'},
    {name:'employmentType',label:'Тип занятости',type:'select',options:directoryValues('employmentTypes')},
    {name:'isBySpecialty',label:'Работа по специальности',type:'select',options:['Да','Нет']},
    {name:'salary',label:'Зарплата, ₽ в месяц',type:'number',min:0},
    {name:'consent',label:'Согласие на обработку ПД получено',type:'select',required:!item,options:['Да']}
  ];
  if(type==='survey') fields=[
    {name:'title',label:'Название опроса',required:true,full:true},{name:'description',label:'Описание',type:'textarea',full:true},
    {name:'audience',label:'Аудитория',placeholder:'Например, выпускники 2025 года'},
    {name:'status',label:'Статус',type:'select',required:true,options:['Черновик','Активен','Завершён']},
    {name:'startDate',label:'Дата начала',type:'date'},{name:'endDate',label:'Дата окончания',type:'date'},
    {name:'targetCount',label:'Ожидаемое количество ответов',type:'number',min:0},
    {name:'questionsText',label:'Вопросы (каждый с новой строки)',type:'textarea',full:true,placeholder:'Текущий статус занятости\nНазвание организации\nРаботаете ли по специальности?'}
  ];
  if(type==='user') fields=[
    {name:'name',label:'ФИО пользователя',required:true},{name:'email',label:'Email',type:'email',required:true},
    {name:'role',label:'Роль',type:'select',required:true,options:roleOptions},
    {name:'status',label:'Статус',type:'select',required:true,options:['Активен','Отключён']},
    {name:'password',label:id?'Новый пароль (необязательно)':'Пароль (не менее 8 символов)',type:'password',required:!id}
  ];
  const data={...(item||{})};
  if(type==='student'&&!item){data.status='Студент выпускного курса';data.graduationYear=new Date().getFullYear();}
  if(type==='survey'&&!item){data.status='Черновик';data.startDate=new Date().toISOString().slice(0,10);}
  if(type==='user'&&!item){data.status='Активен';data.role='Сотрудник учебной части';}
  if(type==='survey')data.questionsText=(item?.questions||[]).join('\n');
  modalContext={type,id};
  const fieldsHTML=fields.map(f=>fieldHTML(f,data)).join('');
  showModal(`${item?'Изменить':'Добавить'} ${type==='student'?'карточку выпускника':type==='survey'?'опрос':'пользователя'}`,`<form id="modalForm" class="modal-form-grid">${fieldsHTML}</form>`,`<button type="button" class="btn btn-secondary" data-action="modal-close">Отмена</button><button type="submit" class="btn" form="modalForm">Сохранить</button>`);
  $('#modalForm').addEventListener('submit',saveEntityForm);
}
async function saveEntityForm(event){
  event.preventDefault();
  if(!modalContext) return;
  const {type,id}=modalContext;
  const values=Object.fromEntries(new FormData(event.currentTarget).entries());
  try{
    if(type==='student'){
      const body=gradToApi(values,!id);
      if(id) await api('PATCH',`/graduates/${id}`,body);
      else await api('POST','/graduates',body);
      closeModal(); await reload(id?'Изменения сохранены':'Запись добавлена');
    }else if(type==='survey'){
      if(values.startDate&&values.endDate&&values.endDate<values.startDate){toast('Дата окончания не может быть раньше даты начала');return;}
      const body=surveyToApi(values);
      if(id) await api('PATCH',`/surveys/${id}`,body);
      else await api('POST','/surveys',body);
      closeModal(); await reload(id?'Изменения сохранены':'Опрос создан');
    }else if(type==='user'){
      const body=userToApi(values);
      if(id) await api('PATCH',`/users/${id}`,body);
      else await api('POST','/users',body);
      closeModal(); await reload(id?'Изменения сохранены':'Пользователь добавлен');
    }
  }catch(error){ toast(errorText(error)); }
}
function viewStudent(id){
  const g=state.graduates.find(x=>x.id===id);if(!g)return;
  const details=[['ФИО',g.fullName],['Email',g.email],['Телефон',g.phone],['Группа',g.groupName],['Специальность',g.specialty],['Год выпуска',g.graduationYear],['Статус',g.status],['Организация',g.companyName],['Должность',g.position],['Тип занятости',g.employmentType],['Работа по специальности',g.isBySpecialty],['Зарплата',formatMoney(g.salary)],['Согласие на обработку ПД',g.consent?'Получено':'Не отмечено']];
  const content=`<div class="detail-grid">${details.map(([label,value])=>`<div class="detail-item"><span>${esc(label)}</span><strong>${esc(value||'—')}</strong></div>`).join('')}</div><div class="detail-actions"><button class="btn btn-secondary" data-action="student-responses" data-id="${esc(id)}">Ответы выпускника</button></div>`;
  showModal('Карточка выпускника',content,`<button class="btn btn-secondary" data-action="modal-close">Закрыть</button><button class="btn" data-action="edit-student-from-modal" data-id="${esc(id)}">Редактировать</button>`,'КАРТОЧКА');
}
function viewStudentResponses(id){
  const g=state.graduates.find(x=>x.id===id);if(!g)return;
  const list=state.responses.filter(r=>r.graduateId===id);
  const content=list.length?`<div class="table-scroll"><table><thead><tr><th>ОПРОС</th><th>ДАТА</th><th>СТАТУС</th></tr></thead><tbody>${list.map(r=>`<tr><td>${esc(r.surveyTitle)}</td><td>${formatDate(r.date)}</td><td>${statusBadge(r.status)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty-state">У этого выпускника пока нет ответов</div>';
  showModal(`Ответы: ${g.fullName}`,content,`<button class="btn btn-secondary" data-action="modal-close">Закрыть</button>`,'ИСТОРИЯ ОТВЕТОВ');
}
function viewResponse(id){
  const r=state.responses.find(x=>x.id===id);if(!r){toast('Ответ не найден');return;}
  const g=state.graduates.find(x=>x.id===r.graduateId);
  const content=`<div class="detail-grid"><div class="detail-item"><span>Участник</span><strong>${esc(r.name)}</strong></div><div class="detail-item"><span>Email</span><strong>${esc(r.email||'—')}</strong></div><div class="detail-item"><span>Опрос</span><strong>${esc(r.surveyTitle||'—')}</strong></div><div class="detail-item"><span>Дата получения</span><strong>${formatDate(r.date)}</strong></div><div class="detail-item"><span>Организация</span><strong>${esc(r.company||'—')}</strong></div><div class="detail-item"><span>Должность</span><strong>${esc(r.position||'—')}</strong></div><div class="detail-item"><span>Зарплата</span><strong>${esc(formatMoney(r.salary))}</strong></div><div class="detail-item"><span>По специальности</span><strong>${esc(r.bySpecialty||'—')}</strong></div></div><div class="modal-field" style="margin-top:16px"><label for="responseStatusEdit">Статус обработки</label><select id="responseStatusEdit"><option ${r.status==='Обработано'?'selected':''}>Обработано</option><option ${r.status==='Проверка'?'selected':''}>Проверка</option><option ${r.status==='Ошибка'?'selected':''}>Ошибка</option></select></div>${g?`<p class="muted">Связанная карточка: ${esc(g.fullName)}</p>`:''}`;
  showModal('Просмотр ответа',content,`<button class="btn btn-secondary" data-action="modal-close">Закрыть</button><button class="btn btn-secondary" data-action="delete-response" data-id="${esc(id)}">Удалить ответ</button><button class="btn" data-action="save-response-status" data-id="${esc(id)}">Сохранить статус</button>`,'ОТВЕТ НА ОПРОС');
}
function showSurveyResults(id){
  const s=state.surveys.find(x=>x.id===id);if(!s)return;
  const list=state.responses.filter(r=>r.surveyId===id);const done=list.filter(r=>r.status==='Обработано').length;const pending=list.filter(r=>r.status==='Проверка').length;const errors=list.filter(r=>r.status==='Ошибка').length;
  const content=`<div class="stats-grid" style="grid-template-columns:repeat(3,1fr)"><div class="stat-card"><div class="stat-label">Всего ответов</div><strong>${list.length}</strong></div><div class="stat-card"><div class="stat-label">Обработано</div><strong>${done}</strong></div><div class="stat-card"><div class="stat-label">Ошибки</div><strong>${errors}</strong></div></div><div class="detail-grid"><div class="detail-item"><span>Название</span><strong>${esc(s.title)}</strong></div><div class="detail-item"><span>Период</span><strong>${formatDate(s.startDate)} — ${formatDate(s.endDate)}</strong></div><div class="detail-item"><span>На проверке</span><strong>${pending}</strong></div><div class="detail-item"><span>Ожидаемое количество</span><strong>${Number(s.targetCount)||'Не задано'}</strong></div></div><h3 style="font-size:12px;margin:19px 0 8px">Состав опроса</h3><ol style="font-size:10px;line-height:1.8;color:#5e6b7d;padding-left:18px">${(s.questions||[]).map(q=>`<li>${esc(q)}</li>`).join('')||'<li>Вопросы не добавлены</li>'}</ol>`;
  showModal('Результаты опроса',content,`<button class="btn btn-secondary" data-action="modal-close">Закрыть</button><button class="btn" data-action="filter-survey-responses" data-id="${esc(id)}">Открыть ответы</button>`,'СТАТИСТИКА ОПРОСА');
}

function openDirectoryForm(id=null){
  const items=state.directories[activeDirectory]||[];
  const item=id?items.find(x=>x.id===id):null;
  modalContext={type:'directory',id};
  showModal(`${item?'Изменить':'Добавить'} значение справочника`,
    `<form id="modalForm"><div class="modal-field"><label for="directoryName">Справочник</label><input id="directoryName" value="${esc(directoryNames[activeDirectory])}" disabled></div><div class="modal-field"><label for="directoryValue">Значение *</label><input id="directoryValue" name="value" required value="${esc(item?item.value:'')}"></div></form>`,
    `<button class="btn btn-secondary" type="button" data-action="modal-close">Отмена</button><button class="btn" type="submit" form="modalForm">Сохранить</button>`,'СПРАВОЧНИК');
  $('#modalForm').addEventListener('submit',saveDirectoryForm);
}
async function saveDirectoryForm(event){
  event.preventDefault();
  const value=String(new FormData(event.currentTarget).get('value')||'').trim();
  if(!value){toast('Введите значение');return;}
  const id=modalContext?.id;
  try{
    if(id) await api('PATCH',`/directories/${activeDirectory}/${id}`,{value});
    else await api('POST',`/directories/${activeDirectory}`,{value});
    closeModal(); await reload('Справочник сохранён');
  }catch(error){ toast(errorText(error)); }
}
function openIntegrationForm(key){
  const integration=state.integrations[key];
  if(!integration) return;
  modalContext={type:'integration',id:key};
  const content=`<form id="modalForm"><div class="modal-field"><label>Название интеграции</label><input value="${esc(integration.name)}" disabled></div><div class="modal-field"><label for="integrationUrl">URL или адрес подключения</label><input id="integrationUrl" name="url" type="url" value="${esc(integration.url||'')}" placeholder="https://…"></div><div class="modal-field"><label for="integrationStatus">Статус</label><select id="integrationStatus" name="status"><option ${integration.status==='Не подключено'?'selected':''}>Не подключено</option><option ${integration.status==='Настроено'?'selected':''}>Настроено</option></select></div><p class="help-note">Здесь сохраняются только адрес и статус. Ключи и секреты задаются на сервере.</p></form>`;
  showModal('Параметры интеграции',content,`<button class="btn btn-secondary" data-action="modal-close">Отмена</button><button class="btn" type="submit" form="modalForm">Сохранить</button>`,'НАСТРОЙКА ИНТЕГРАЦИИ');
  $('#modalForm').addEventListener('submit',saveIntegrationForm);
}
async function saveIntegrationForm(event){
  event.preventDefault();
  const key=modalContext?.id;
  if(!key) return;
  const f=new FormData(event.currentTarget);
  try{
    await api('PATCH',`/integrations/${key}`,{url:String(f.get('url')||'').trim(),status:f.get('status')});
    closeModal(); await reload('Параметры сохранены');
  }catch(error){ toast(errorText(error)); }
}
function copyText(text){
  if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(text).then(()=>toast('Ссылка скопирована')).catch(()=>fallbackCopy(text));}
  else fallbackCopy(text);
}
function fallbackCopy(text){const area=document.createElement('textarea');area.value=text;document.body.appendChild(area);area.select();try{document.execCommand('copy');toast('Ссылка скопирована');}catch(e){prompt('Скопируйте ссылку:',text);}area.remove();}
function createSurveyLink(id){
  const s=state.surveys.find(x=>x.id===id);if(!s)return;
  const token=uid('invite');const base=location.href.split('#')[0];const link=`${base}#graduate?survey=${encodeURIComponent(id)}&token=${encodeURIComponent(token)}`;
  showModal('Ссылка на анкету',`<p style="font-size:11px;color:#68768b;line-height:1.6">Ссылка открывает публичную анкету с выбранным опросом. Пока сайт работает локально, ссылка доступна только там, где открыт этот сайт. После публикации frontend ссылка будет доступна выпускникам.</p><div class="modal-field"><label for="surveyUrl">Ссылка</label><input id="surveyUrl" value="${esc(link)}" readonly></div><div class="detail-item"><span>Опрос</span><strong>${esc(s.title)}</strong></div>`,`<button class="btn btn-secondary" data-action="modal-close">Закрыть</button><button class="btn" data-action="copy-survey-link">Копировать ссылку</button>`,'ПРИГЛАШЕНИЕ');
}

function csvCell(value){const s=String(value??'');return /[";,\n\r]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;}
function downloadFile(filename,content,type='text/csv;charset=utf-8'){const blob=new Blob(['\uFEFF',content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);}
function exportGraduates(){const headers=['id','full_name','email','phone','group_name','specialty','graduation_year','status','company_name','position','employment_type','is_by_specialty','salary'];const rows=state.graduates.map(g=>[g.id,g.fullName,g.email,g.phone,g.groupName,g.specialty,g.graduationYear,g.status,g.companyName,g.position,g.employmentType,g.isBySpecialty,g.salary]);downloadFile('graduates.csv',[headers,...rows].map(r=>r.map(csvCell).join(';')).join('\r\n'));renderAudit();toast('Файл graduates.csv сформирован');}
function exportResponses(){const headers=['id','respondent','email','survey','date','status','company','position','salary','by_specialty'];const rows=state.responses.map(r=>[r.id,r.name,r.email,r.surveyTitle,r.date,r.status,r.company,r.position,r.salary,r.bySpecialty]);downloadFile('survey_responses.csv',[headers,...rows].map(r=>r.map(csvCell).join(';')).join('\r\n'));renderAudit();toast('Файл с ответами сформирован');}
function exportReport(){const grads=state.graduates;const rows=[['Показатель','Значение'],['Всего выпускников',grads.length],['Трудоустроено',grads.filter(g=>g.status==='Трудоустроен').length],['Ответов на опросы',state.responses.length],['Опросов',state.surveys.length],['Пользователей',state.users.length],[],['ФИО','Email','Группа','Специальность','Год выпуска','Статус','Организация','Должность','Зарплата'],...grads.map(g=>[g.fullName,g.email,g.groupName,g.specialty,g.graduationYear,g.status,g.companyName,g.position,g.salary])];downloadFile('employment_report.csv',rows.map(r=>r.map(csvCell).join(';')).join('\r\n'));renderAudit();toast('Отчёт сформирован');}

function parseCSV(text){
  const rows=[];let row=[],cell='',quoted=false;
  for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}else if((c===';'||c===',')&&!quoted){row.push(cell);cell='';}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(v=>v.trim()!==''))rows.push(row);row=[];cell='';}else cell+=c;}
  row.push(cell);if(row.some(v=>v.trim()!==''))rows.push(row);return rows;
}
function normalizeHeader(header){return String(header||'').trim().replace(/^\uFEFF/,'').toLowerCase().replace(/[\s-]+/g,'_');}
const IMPORT_SOURCE_LABELS={college:'ИС колледжа',google_forms:'Google Forms',yandex_forms:'Яндекс Формы'};
async function importCSV(){
  const file=$('#csvFile').files[0];
  if(!file){toast('Сначала выберите CSV-файл');return;}
  const sourceType=$('#importSource').value||'college';
  const surveyId=$('#importSurvey').value;
  const body={sourceType,csv:null};
  try{
    body.csv=await file.text();
    if(surveyId) body.surveyId=surveyId;
    const result=await api('POST','/imports/graduates',body);
    const errorLines=result.errors.slice(0,5).map(e=>{const fields=Object.keys(e.fields||{}).map(k=>FIELD_LABELS[k]||k);return `строка ${e.line}: ${e.message}${fields.length?' ('+fields.join(', ')+')':''}`;}).join('; ');
    $('#importResult').textContent=`Импорт из «${IMPORT_SOURCE_LABELS[sourceType]}» завершён. Загружено: ${result.importedRows} из ${result.totalRows}; с ошибками: ${result.errorRows}.${errorLines?' '+errorLines:''}`;
    toast('Импорт CSV завершён');
    await reload();
  }catch(error){
    $('#importResult').textContent=`Ошибка импорта: ${errorText(error)}`;
    toast(`Ошибка импорта: ${errorText(error)}`);
  }
}
function downloadTemplate(){
  const rows=[['full_name','email','phone','group_name','specialty','graduation_year','status','consent'],
    ['Иванов Иван Иванович','ivanov@example.ru','+7 900 000-00-00','ИС-21','Информационные системы','2025','Трудоустроен','Да']];
  downloadFile('graduates_template.csv',rows.map(r=>r.map(csvCell).join(';')).join('\n'));
}
async function submitGraduateForm(event){
  event.preventDefault();
  const form=event.currentTarget;
  if(!form.reportValidity()) return;
  const f=new FormData(form);
  const surveyId=String(f.get('surveyId')||'');
  if(!surveyId){toast('Выберите опрос');return;}
  const status=String(f.get('status')||'');
  const employed=status==='Трудоустроен';
  const bySpec=String(f.get('bySpecialty')||'');
  const body={
    graduate:{
      fullName:String(f.get('fullName')||'').trim(),email:String(f.get('email')||'').trim(),
      phone:String(f.get('phone')||'')||null,groupName:String(f.get('group')||'')||null,
      specialty:String(f.get('specialty')||'')||null,graduationYear:Number(f.get('year'))||null,
      status:GRAD_API[status]||'other'
    },
    employment:employed?{
      companyName:String(f.get('company')||'')||null,position:String(f.get('position')||'')||null,
      employmentType:String(f.get('employmentType')||'')||null,
      isBySpecialty:bySpec==='Да'?true:bySpec==='Нет'?false:null,
      salary:Number(f.get('salary'))||null,currency:'RUB'
    }:null,
    consentPersonalData:f.get('consent')==='on'
  };
  try{
    await api('POST',`/public/surveys/${encodeURIComponent(surveyId)}/responses`,body,{auth:false});
    form.hidden=true;
    $('#graduateSuccess').hidden=false;
    toast('Анкета отправлена');
    if(me) await reload();
  }catch(error){ toast(errorText(error)); }
}
function resetGraduateForm(){const form=$('#graduateForm');form.reset();form.hidden=false;$('#graduateSuccess').hidden=true;populateGraduateSurveys();}

async function handleAction(action,button){
  try{ await runAction(action,button.dataset.id); }
  catch(error){ handleError(error); }
}
async function runAction(action,id){
  switch(action){
    case 'modal-close': closeModal(); break;
    case 'open-profile': openProfile(); break;
    case 'save-profile': await saveProfile(); break;
    case 'logout': await logout(); break;
    case 'refresh': await reload('Данные обновлены'); break;
    case 'add-student': openEntityForm('student'); break;
    case 'edit-student': openEntityForm('student',id); break;
    case 'view-student': viewStudent(id); break;
    case 'edit-student-from-modal': closeModal(); openEntityForm('student',id); break;
    case 'student-responses': viewStudentResponses(id); break;
    case 'delete-student': {
      const g=state.graduates.find(x=>x.id===id);
      if(g&&confirmDelete(g.fullName)){ await api('DELETE',`/graduates/${id}`); await reload('Карточка удалена'); }
      break;
    }
    case 'clear-student-filters': $('#studentSearch').value=''; $('#yearFilter').value=''; $('#statusFilter').value=''; renderStudents(); break;
    case 'add-survey': openEntityForm('survey'); break;
    case 'edit-survey': openEntityForm('survey',id); break;
    case 'survey-results': showSurveyResults(id); break;
    case 'survey-link': createSurveyLink(id); break;
    case 'delete-survey': {
      const s=state.surveys.find(x=>x.id===id);
      if(s&&confirmDelete(s.title)){ await api('DELETE',`/surveys/${id}`); await reload('Опрос удалён'); }
      break;
    }
    case 'view-response': viewResponse(id); break;
    case 'save-response-status': {
      const status=$('#responseStatusEdit')?.value;
      const apiStatus=RESP_API[status];
      if(apiStatus){ await api('PATCH',`/survey-responses/${id}`,{status:apiStatus}); closeModal(); await reload('Статус ответа обновлён'); }
      break;
    }
    case 'delete-response': {
      const r=state.responses.find(x=>x.id===id);
      if(r&&confirmDelete(r.name)){ await api('DELETE',`/survey-responses/${id}`); closeModal(); await reload('Ответ удалён'); }
      break;
    }
    case 'filter-survey-responses': closeModal(); navigate('responses'); $('#responseSurveyFilter').value=id; renderResponses(); break;
    case 'add-directory': openDirectoryForm(); break;
    case 'edit-directory': openDirectoryForm(id); break;
    case 'delete-directory': {
      const item=(state.directories[activeDirectory]||[]).find(x=>x.id===id);
      if(item&&confirm(`Удалить значение «${item.value}»?`)){ await api('DELETE',`/directories/${activeDirectory}/${id}`); await reload('Значение удалено'); }
      break;
    }
    case 'add-user': openEntityForm('user'); break;
    case 'edit-user': openEntityForm('user',id); break;
    case 'toggle-user': {
      const u=state.users.find(x=>x.id===id);
      if(u){ await api('PATCH',`/users/${id}`,{isActive:u.status!=='Активен'}); await reload('Статус пользователя изменён'); }
      break;
    }
    case 'delete-user': {
      const u=state.users.find(x=>x.id===id);
      if(u&&confirmDelete(u.name)){ await api('DELETE',`/users/${id}`); await reload('Пользователь удалён'); }
      break;
    }
    case 'edit-integration': openIntegrationForm(id); break;
    case 'import-csv': await importCSV(); break;
    case 'download-template': downloadTemplate(); toast('Шаблон CSV скачан'); break;
    case 'clear-audit': toast('Журнал действий хранится на сервере и не очищается'); break;
    case 'export-graduates': exportGraduates(); break;
    case 'export-responses': exportResponses(); break;
    case 'export-report': exportReport(); break;
    case 'copy-survey-link': { const value=$('#surveyUrl')?.value; if(value) copyText(value); break; }
    case 'graduate-reset': resetGraduateForm(); break;
    default: console.warn('Неизвестное действие:',action);
  }
}
$('#mainNav').addEventListener('click',event=>{const button=event.target.closest('[data-page]');if(button)navigate(button.dataset.page);});
document.addEventListener('click',event=>{
  const nav=event.target.closest('[data-nav]');if(nav){navigate(nav.dataset.nav);return;}
  const action=event.target.closest('[data-action]');if(action)handleAction(action.dataset.action,action);
});
$('#modalBackdrop').addEventListener('click',event=>{if(event.target===$('#modalBackdrop'))closeModal();});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeModal();});
$('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$('#studentSearch').addEventListener('input',renderStudents);$('#yearFilter').addEventListener('change',renderStudents);$('#statusFilter').addEventListener('change',renderStudents);
$('#responseSearch').addEventListener('input',renderResponses);$('#responseStatus').addEventListener('change',renderResponses);$('#responseSurveyFilter').addEventListener('change',renderResponses);
$('#directoryType').addEventListener('change',()=>{activeDirectory=$('#directoryType').value;renderDirectories();});
$('#analyticsYear').addEventListener('change',async()=>{
  try{ state.analytics=await api('GET',`/reports/employment${analyticsQuery()}`); renderAnalytics(); }
  catch(error){ handleError(error); }
});
$('#graduateForm').addEventListener('submit',submitGraduateForm);
window.addEventListener('hashchange',()=>{const page=currentHashPage();if(pageNames[page])navigate(page,false);});
window.addEventListener('popstate',()=>{const page=currentHashPage();if(pageNames[page])navigate(page,false);});

$('#loginForm').addEventListener('submit',submitLogin);
(async function init(){
  const initial=currentHashPage();
  navigate(pageNames[initial]?initial:'dashboard',false);
  if(!token){ showLogin(); return; }
  try{ await startSession(); }
  catch(error){
    if(error instanceof ApiFailure&&error.status===401) return;
    setConnection(false);
    toast(errorText(error));
  }
})();