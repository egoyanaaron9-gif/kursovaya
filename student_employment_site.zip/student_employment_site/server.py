"""Минимальный локальный сервер для запуска статического frontend."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os
import webbrowser

ROOT = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = 5500

if __name__ == "__main__":
    os.chdir(ROOT)
    address = f"http://{HOST}:{PORT}"
    print(f"Сайт доступен: {address}")
    print("Для остановки нажмите Ctrl+C")
    try:
        webbrowser.open(address)
    except Exception:
        pass
    ThreadingHTTPServer((HOST, PORT), SimpleHTTPRequestHandler).serve_forever()
