# Контракт frontend ↔ backend

Документ предназначен для согласования серверной части с текущим frontend. Это рекомендуемый контракт для реализации; наличие перечисленных endpoint'ов не подразумевается до их создания коллегой.

## Общие правила

- Базовый адрес: `/api/v1`.
- Формат данных: JSON, кодировка UTF-8.
- Идентификаторы: UUID или строковые ID, которые сервер возвращает клиенту.
- Даты: `YYYY-MM-DD`; дата и время событий — ISO 8601 с часовым поясом.
- Для списков желательно возвращать `{ "items": [], "total": 0, "page": 1, "pageSize": 20 }`.
- Ошибка: `{ "error": { "code": "VALIDATION_ERROR", "message": "Понятное описание", "fields": {} } }`.
- Защищённые запросы используют `Authorization: Bearer <access_token>`.

## Сущности и поля

### Graduate — выпускник / студент

Сущность соответствует `graduate` из модели данных проекта. Поля для интерфейса:

```json
{
  "id": "uuid",
  "externalId": "college-system-id",
  "fullName": "Иван Петров",
  "email": "ivan@example.ru",
  "phone": "+7 900 000-00-00",
  "groupName": "ИС-21",
  "specialtyCode": "09.02.07",
  "specialty": "Информационные системы",
  "graduationYear": 2025,
  "status": "employed",
  "city": "Владивосток",
  "region": "Приморский край",
  "consentPersonalData": true,
  "createdAt": "2026-11-16T10:00:00Z",
  "updatedAt": "2026-11-16T10:00:00Z",
  "employment": {
    "companyName": "ООО Технологии",
    "position": "Системный аналитик",
    "employmentType": "full_time",
    "isBySpecialty": true,
    "salary": 72000,
    "currency": "RUB",
    "salaryPeriod": "month",
    "isCurrent": true
  },
  "skills": [
    { "id": "skill-uuid", "name": "SQL", "level": 4 }
  ]
}
```

Статусы в API рекомендуется хранить как машинные значения: `student`, `employed`, `unemployed`, `continuing_education`, `other`. Frontend должен преобразовывать их в подписи на русском.

### Survey — опрос

Соответствует `survey` из модели данных.

```json
{
  "id": "uuid",
  "title": "Мониторинг трудоустройства 2025",
  "description": "Сбор информации о занятости выпускников",
  "provider": "internal",
  "externalFormId": null,
  "formUrl": null,
  "audienceFilter": { "graduationYears": [2025] },
  "status": "active",
  "startDate": "2026-10-01",
  "endDate": "2026-11-30",
  "questionsSchema": [
    { "key": "employmentStatus", "label": "Текущий статус занятости", "type": "select", "required": true }
  ],
  "createdAt": "2026-09-20T10:00:00Z"
}
```

Допустимые статусы: `draft`, `active`, `closed`. Провайдеры: `internal`, `google_forms`, `yandex_forms`.

### SurveyResponse — ответ на опрос

Соответствует `survey_response`.

```json
{
  "id": "uuid",
  "surveyId": "survey-uuid",
  "graduateId": "graduate-uuid",
  "respondentIdentifier": "ivan@example.ru",
  "rawPayload": { "originalQuestion": "original answer" },
  "processedPayload": { "companyName": "ООО Технологии", "salary": 72000 },
  "status": "received",
  "receivedAt": "2026-11-16T10:15:00Z",
  "appliedAt": null
}
```

Рекомендуемые статусы backend: `received`, `parsed`, `applied`, `error`. В очереди интерфейса их можно отображать как «Проверка», «Обработано» и «Ошибка».

### Directory — справочники

Основные типы: `specialties`, `employers`, `skills`, `employment_types`, `groups`, `industries`, `currencies`.

### User — пользователь

```json
{
  "id": "uuid",
  "fullName": "Александр Куратор",
  "email": "curator@college.ru",
  "role": "curator",
  "isActive": true
}
```

Рекомендуемые роли: `admin`, `curator`, `analyst`, `director`, `graduate`. Права проверяются только backend'ом; переключатель роли в текущем frontend является предпросмотром.

## Endpoint'ы для первой интеграции

| Метод | Endpoint | Назначение |
|---|---|---|
| POST | `/auth/login` | Вход сотрудника |
| POST | `/auth/refresh` | Обновление токена |
| GET | `/auth/me` | Текущий пользователь и его роль |
| GET | `/graduates` | Список, поиск и фильтрация выпускников |
| POST | `/graduates` | Создать карточку |
| GET | `/graduates/{id}` | Получить карточку и связанные данные |
| PATCH | `/graduates/{id}` | Изменить карточку |
| DELETE | `/graduates/{id}` | Удалить/архивировать карточку |
| GET | `/surveys` | Список опросов |
| POST | `/surveys` | Создать опрос |
| GET | `/surveys/{id}` | Получить опрос и схему вопросов |
| PATCH | `/surveys/{id}` | Изменить опрос |
| DELETE | `/surveys/{id}` | Удалить/архивировать опрос |
| GET | `/survey-responses` | Список ответов с фильтрами |
| GET | `/survey-responses/{id}` | Открыть ответ |
| PATCH | `/survey-responses/{id}` | Изменить статус/результат обработки |
| POST | `/public/surveys/{id}/responses` | Отправить публичную анкету |
| GET | `/directories/{type}` | Получить справочник |
| POST | `/directories/{type}` | Добавить значение справочника |
| PATCH | `/directories/{type}/{id}` | Изменить значение |
| DELETE | `/directories/{type}/{id}` | Удалить значение |
| GET | `/users` | Список пользователей |
| POST | `/users` | Создать пользователя |
| PATCH | `/users/{id}` | Изменить пользователя/роль/активность |
| GET | `/reports/employment` | Агрегаты для дашборда и отчётов |
| GET | `/audit-log` | История действий |
| POST | `/imports/graduates` | Загрузить CSV/Excel для импорта |
| GET | `/imports/{id}` | Статус и результат импорта |
| GET | `/integrations` | Список настроек интеграций без секретов |
| PATCH | `/integrations/{provider}` | Обновить несекретные настройки |
| POST | `/webhooks/google-forms/{surveyId}` | Приём webhook Google Forms |
| POST | `/webhooks/yandex-forms/{surveyId}` | Приём webhook Yandex Forms |

## Примеры первой интеграции

### Получение выпускников

`GET /api/v1/graduates?search=Петров&graduationYear=2025&status=employed&page=1&pageSize=20`

Ответ:

```json
{
  "items": [
    {
      "id": "graduate-uuid",
      "fullName": "Иван Петров",
      "email": "ivan@example.ru",
      "groupName": "ИС-21",
      "specialty": "Информационные системы",
      "graduationYear": 2025,
      "status": "employed"
    }
  ],
  "total": 1,
  "page": 1,
  "pageSize": 20
}
```

### Отправка публичной анкеты

`POST /api/v1/public/surveys/{surveyId}/responses`

```json
{
  "token": "invitation-token",
  "graduate": {
    "fullName": "Иван Петров",
    "email": "ivan@example.ru",
    "phone": "+7 900 000-00-00",
    "groupName": "ИС-21",
    "specialty": "Информационные системы",
    "graduationYear": 2025
  },
  "employment": {
    "status": "employed",
    "companyName": "ООО Технологии",
    "position": "Системный аналитик",
    "employmentType": "full_time",
    "isBySpecialty": true,
    "salary": 72000,
    "currency": "RUB"
  },
  "consentPersonalData": true
}
```

Ответ:

```json
{
  "responseId": "response-uuid",
  "graduateId": "graduate-uuid",
  "status": "received",
  "receivedAt": "2026-11-16T10:15:00Z"
}
```

## Что важно согласовать до разработки

1. Зафиксировать окончательные машинные значения статусов и ролей.
2. Согласовать поля карточки выпускника и отдельной таблицы `employment` — в описании проекта место работы является самостоятельной сущностью и может быть несколько записей на одного выпускника.
3. Решить, как будут выдаваться и проверяться персональные invitation tokens.
4. Определить единый механизм пагинации, фильтров и формат ошибок.
5. Реализовать проверку согласия на обработку ПД, RBAC и аудит на backend. Скрытие кнопок на frontend не является защитой.
6. Не возвращать секреты интеграций в frontend. Ключи Google/Yandex и webhook secrets хранить на сервере.
