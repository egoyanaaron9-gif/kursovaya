@echo off
setlocal
cd /d "%~dp0"

rem ---- find Python 3 (the py launcher first, then python) ----
set "PYCMD="
py -3 --version >nul 2>&1 && set "PYCMD=py -3"
if not defined PYCMD (
    python --version >nul 2>&1 && set "PYCMD=python"
)
if not defined PYCMD (
    echo.
    echo [ERROR] Python 3 was not found.
    echo Install Python 3.10 or newer from https://www.python.org/downloads/
    echo During installation tick "Add python.exe to PATH".
    echo The "python" entry from the Microsoft Store does not count.
    echo.
    pause
    exit /b 1
)
echo Using: %PYCMD%

rem ---- API: create the database and demo data (runs once) ----
pushd backend
%PYCMD% seed.py
if errorlevel 1 (
    echo.
    echo [ERROR] seed.py failed. The message is above.
    popd
    pause
    exit /b 1
)
popd

rem ---- API server in its own window (keep it open while you work) ----
start "College API" /D "%~dp0backend" cmd /k %PYCMD% server.py

rem ---- website: opens http://127.0.0.1:5500 in the browser ----
echo.
echo Site: http://127.0.0.1:5500   (close this window to stop the site)
%PYCMD% server.py
echo.
echo Site server stopped.
pause
